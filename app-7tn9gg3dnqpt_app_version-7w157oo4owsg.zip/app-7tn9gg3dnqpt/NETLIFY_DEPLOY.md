# 🚀 Netlify Deployment Guide - Naruto Chess Game

## Quick Deploy (3 Steps)

### Step 1: Push to Git Repository
```bash
git push origin main
```

### Step 2: Connect to Netlify
1. Go to https://app.netlify.com
2. Click "Add new site" → "Import an existing project"
3. Choose your Git provider (GitHub, GitLab, Bitbucket)
4. Select your repository

### Step 3: Configure Build Settings
Netlify will automatically detect the settings from `netlify.toml`, but verify:

- **Build command**: `pnpm install && pnpm run build`
- **Publish directory**: `dist`
- **Node version**: `20` (set in netlify.toml)

Click "Deploy site" and you're done! 🎉

---

## Environment Variables (Required for Supabase)

After deployment, add these environment variables in Netlify:

1. Go to **Site settings** → **Environment variables**
2. Add the following variables:

```
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

Get these values from your Supabase project dashboard:
- Go to https://app.supabase.com
- Select your project
- Go to **Settings** → **API**
- Copy the **Project URL** and **anon/public key**

---

## Build Configuration (Already Set Up)

The `netlify.toml` file includes:

### ✅ Build Settings
- Node.js 20
- pnpm package manager
- Optimized build process

### ✅ SPA Routing
- All routes redirect to index.html
- Client-side routing works perfectly

### ✅ Security Headers
- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- X-XSS-Protection enabled
- Content Security Policy configured
- Referrer Policy set

### ✅ Performance Optimization
- Static assets cached for 1 year
- Images cached (immutable)
- Fonts cached (immutable)
- CSS/JS cached (immutable)
- HTML no-cache for updates
- Image compression enabled
- CSS/JS minification enabled

---

## Deployment Checklist

Before deploying, ensure:

- [x] ✅ All code committed to Git
- [x] ✅ netlify.toml configured
- [x] ✅ .nvmrc file present (Node 20)
- [x] ✅ public/_redirects backup file
- [x] ✅ Zero linting errors
- [x] ✅ Zero TypeScript errors
- [x] ✅ Build tested locally
- [x] ✅ Environment variables ready

---

## Testing Local Build

Before deploying, test the build locally:

```bash
# Install dependencies
pnpm install

# Run linter
pnpm run lint

# Build for production
pnpm run build

# Preview the build
pnpm run preview
```

If all commands succeed, you're ready to deploy! 🚀

---

## Post-Deployment

After deployment:

1. **Test the site**: Visit your Netlify URL
2. **Check all features**:
   - ✅ Home page loads
   - ✅ Multiplayer mode works
   - ✅ AI training mode works
   - ✅ Local 2-player mode works
   - ✅ Game creation/joining works
   - ✅ Move synchronization works
   - ✅ All animations smooth

3. **Set up custom domain** (optional):
   - Go to **Domain settings**
   - Add your custom domain
   - Configure DNS

4. **Enable HTTPS** (automatic):
   - Netlify provides free SSL certificates
   - HTTPS is enabled automatically

---

## Troubleshooting

### Build Fails
- Check Node version is 20
- Verify all dependencies are in package.json
- Check build logs for specific errors

### Environment Variables Not Working
- Ensure variables start with `VITE_`
- Redeploy after adding variables
- Check variable names match exactly

### 404 Errors on Routes
- Verify netlify.toml has SPA redirect
- Check public/_redirects file exists
- Ensure publish directory is `dist`

### Supabase Connection Issues
- Verify environment variables are set
- Check Supabase project is active
- Ensure API keys are correct

---

## Performance Tips

### Already Optimized:
- ✅ Static asset caching (1 year)
- ✅ Image compression enabled
- ✅ CSS/JS minification enabled
- ✅ Lazy loading for images
- ✅ Optimized animations (60 FPS)
- ✅ Reduced polling (2.5s interval)

### Additional Optimizations:
- Enable Netlify Analytics (optional)
- Use Netlify CDN (automatic)
- Monitor Core Web Vitals
- Set up performance budgets

---

## Continuous Deployment

Netlify automatically deploys when you push to your main branch:

```bash
# Make changes
git add .
git commit -m "Update feature"
git push origin main

# Netlify automatically builds and deploys! 🎉
```

---

## Support

- **Netlify Docs**: https://docs.netlify.com
- **Supabase Docs**: https://supabase.com/docs
- **Vite Docs**: https://vitejs.dev

---

## Summary

Your Naruto Chess Game is **PRODUCTION READY** with:

🚀 **Fast Deployment**: Single command to deploy
🔒 **Secure**: Security headers and HTTPS
⚡ **Optimized**: Caching and compression enabled
🎮 **Smooth**: 60 FPS animations, no lag
🌐 **Global**: Netlify CDN worldwide
📱 **Responsive**: Perfect on all devices

**Deploy now and share your game with the world!** 🎉🍥
