# Naruto Chess Game - Player Guide

## Welcome to Naruto Chess!

Experience the classic game of chess with your favorite Naruto characters. This game combines strategic chess gameplay with the exciting world of Naruto!

## Game Modes

### 1. Player vs AI
Challenge the computer with four difficulty levels:
- **Easy**: Perfect for beginners learning chess
- **Medium**: Balanced gameplay for casual players
- **Hard**: Challenging for experienced players
- **Expert**: Maximum difficulty for chess masters

### 2. Player vs Player (Local)
Play with a friend on the same device. Take turns making moves on the same board.

### 3. Player vs Player (Online)
Find an opponent online and play in real-time:
- Automatic matchmaking system
- Real-time move synchronization
- Play from anywhere in the world

## Time Controls

Choose your preferred time format:
- **Bullet**: 1 minute per player (fast-paced)
- **Blitz**: 5 minutes per player (quick games)
- **Rapid**: 10 minutes per player (standard)
- **Classical**: 30 minutes per player (tournament style)
- **Unlimited**: No time limit (casual play)

## Game Features

### Move Hints
Enable move hints to see all legal moves for a selected piece. Green highlights show where you can move.

### Drag and Drop
Click and drag pieces to move them, or simply click a piece and then click the destination square.

### Game Controls
- **Undo**: Take back your last move (AI and Local modes only)
- **Reset**: Start a new game
- **Resign**: Forfeit the current game
- **Save**: Save your game to continue later

### Audio
- **Sound Effects**: Hear different sounds for moves, captures, checks, and checkmates
- **Background Music**: Enjoy Naruto-themed background music
- Toggle audio on/off anytime during gameplay

## Naruto Theme

### Character Pieces
- **King**: Naruto Uzumaki (♔/♚)
- **Queen**: Sasuke Uchiha (♕/♛)
- **Rook**: Gaara (♖/♜)
- **Bishop**: Kakashi Hatake (♗/♝)
- **Knight**: Rock Lee (♘/♞)
- **Pawn**: Shadow Clone (♙/♟)

### Visual Effects
- Konoha village-themed chessboard
- Chakra glow effects on selected pieces
- Smooth animations for piece movements
- Orange and blue color scheme inspired by Naruto's outfit

## How to Play

1. **Start**: Choose your game mode from the home screen
2. **Settings**: Configure difficulty, time control, and audio preferences
3. **Play**: Make moves by clicking or dragging pieces
4. **Win**: Checkmate your opponent's king to win!

## Chess Rules

### Basic Movement
- **King**: One square in any direction
- **Queen**: Any number of squares in any direction
- **Rook**: Any number of squares horizontally or vertically
- **Bishop**: Any number of squares diagonally
- **Knight**: L-shaped move (2 squares in one direction, 1 square perpendicular)
- **Pawn**: One square forward (two squares on first move), captures diagonally

### Special Moves
- **Castling**: Move king two squares toward rook, rook jumps over king
- **En Passant**: Special pawn capture move
- **Promotion**: Pawn reaching the opposite end becomes a queen, rook, bishop, or knight

### Winning Conditions
- **Checkmate**: Opponent's king is under attack and cannot escape
- **Resignation**: Opponent forfeits the game
- **Timeout**: Opponent runs out of time

### Draw Conditions
- **Stalemate**: Player has no legal moves but is not in check
- **Agreement**: Both players agree to a draw

## Tips for Success

1. **Control the Center**: Occupy and control the center squares
2. **Develop Pieces**: Move knights and bishops early
3. **Protect Your King**: Castle early for king safety
4. **Think Ahead**: Plan your moves and anticipate opponent's responses
5. **Use Hints**: Enable move hints when learning or in difficult positions

## Online Play Tips

- Stable internet connection recommended
- Games are saved automatically
- If disconnected, the game may be marked as abandoned
- Be respectful to your opponents

## Keyboard Shortcuts

- **Esc**: Return to menu (when available)
- **Space**: Toggle move hints (in settings)

## Troubleshooting

### Game Not Loading
- Check your internet connection
- Refresh the page
- Clear browser cache

### Audio Not Playing
- Check browser audio permissions
- Ensure device volume is not muted
- Try toggling audio settings in game

### Online Matchmaking Issues
- Wait up to 60 seconds for opponent
- Try different time controls
- Check internet connection

## Have Fun!

Enjoy your ninja chess battles! May the best strategist win! 🍥⚡

---

**Note**: This game uses standard chess rules. If you're new to chess, consider starting with the Easy AI difficulty to learn the basics.
