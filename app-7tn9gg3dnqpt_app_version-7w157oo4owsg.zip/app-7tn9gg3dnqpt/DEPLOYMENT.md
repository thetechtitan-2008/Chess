# Netlify Deployment Guide for Naruto Chess Game

## Prerequisites
- A Netlify account (free tier works perfectly)
- Git repository with your code

## Deployment Methods

### Method 1: Deploy via Netlify UI (Recommended)

1. **Push your code to a Git repository** (GitHub, GitLab, or Bitbucket)
   ```bash
   git push origin master
   ```

2. **Log in to Netlify**
   - Go to https://app.netlify.com
   - Sign up or log in

3. **Create a new site**
   - Click "Add new site" → "Import an existing project"
   - Choose your Git provider
   - Select your repository

4. **Configure build settings**
   - Build command: `pnpm install && pnpm run build`
   - Publish directory: `dist`
   - Node version: `20` (automatically detected from .nvmrc)

5. **Deploy**
   - Click "Deploy site"
   - Wait for the build to complete (usually 2-3 minutes)
   - Your site will be live at a random Netlify URL

6. **Custom domain (optional)**
   - Go to "Domain settings"
   - Add your custom domain
   - Follow DNS configuration instructions

### Method 2: Deploy via Netlify CLI

1. **Install Netlify CLI**
   ```bash
   npm install -g netlify-cli
   ```

2. **Login to Netlify**
   ```bash
   netlify login
   ```

3. **Build your project**
   ```bash
   pnpm install
   pnpm run build
   ```

4. **Deploy**
   ```bash
   # For a draft deploy
   netlify deploy

   # For production deploy
   netlify deploy --prod
   ```

### Method 3: Drag and Drop (Quick Test)

1. **Build locally**
   ```bash
   pnpm install
   pnpm run build
   ```

2. **Go to Netlify**
   - Visit https://app.netlify.com/drop
   - Drag and drop the `dist` folder
   - Your site will be live instantly

## Configuration Files

### netlify.toml
This file is already configured with:
- ✅ Build command and publish directory
- ✅ Node version 20
- ✅ SPA redirects for React Router
- ✅ Security headers (XSS, CSP, etc.)
- ✅ Cache optimization for static assets
- ✅ Image and font caching
- ✅ Build processing optimization

### .nvmrc
Specifies Node.js version 20 for consistent builds.

### public/_redirects
Backup redirect configuration for SPA routing.

## Build Configuration

### Build Command
```bash
pnpm install && pnpm run build
```

### Publish Directory
```
dist
```

### Node Version
```
20
```

## Environment Variables

This project doesn't require any environment variables for basic deployment. All assets are served from CDN.

If you need to add environment variables in the future:
1. Go to Site settings → Environment variables
2. Add your variables
3. Redeploy the site

## Post-Deployment Checklist

After deployment, verify:
- ✅ Homepage loads correctly
- ✅ All images display properly
- ✅ Theme toggle (light/dark mode) works
- ✅ Navigation between pages works
- ✅ Intro splash screen appears on first visit
- ✅ Game modes are accessible
- ✅ Responsive design works on mobile
- ✅ No console errors in browser DevTools

## Performance Optimizations

The site is already optimized with:
- ✅ Lazy loading for images
- ✅ Optimized particle animations
- ✅ CSS will-change for smooth animations
- ✅ Asset caching (1 year for static files)
- ✅ Minified CSS and JavaScript
- ✅ Compressed images
- ✅ Security headers

## Troubleshooting

### Build Fails
- Check that Node version is 20
- Ensure all dependencies are in package.json
- Check build logs for specific errors

### 404 Errors on Routes
- Verify netlify.toml has SPA redirects
- Check that _redirects file exists in public folder

### Images Not Loading
- Verify image URLs are correct
- Check browser console for CORS errors
- Ensure CDN URLs are accessible

### Slow Performance
- Enable Netlify's asset optimization
- Check that caching headers are applied
- Use Lighthouse to identify bottlenecks

## Continuous Deployment

Netlify automatically deploys when you push to your repository:
1. Make changes to your code
2. Commit and push to Git
3. Netlify automatically builds and deploys
4. Check deploy status in Netlify dashboard

## Custom Domain Setup

1. **Add domain in Netlify**
   - Go to Domain settings
   - Click "Add custom domain"
   - Enter your domain name

2. **Configure DNS**
   - Add Netlify's nameservers to your domain registrar
   - Or add A/CNAME records as instructed

3. **Enable HTTPS**
   - Netlify automatically provisions SSL certificate
   - Usually takes 1-2 minutes

## Monitoring

- **Deploy logs**: Check build logs in Netlify dashboard
- **Analytics**: Enable Netlify Analytics for visitor stats
- **Performance**: Use Lighthouse or WebPageTest
- **Errors**: Check browser console and Netlify logs

## Support

- Netlify Docs: https://docs.netlify.com
- Netlify Community: https://answers.netlify.com
- Vite Docs: https://vitejs.dev

## Summary

Your Naruto Chess Game is fully configured for Netlify deployment with:
- ⚡ Optimized build process
- 🔒 Security headers
- 🚀 Fast loading with caching
- 📱 Mobile-responsive
- 🎨 Beautiful Naruto theme
- ✨ Smooth animations
- 🌓 Light/dark mode

Just push to Git and deploy! 🎉
