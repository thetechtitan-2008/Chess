import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ChessEngine } from '@/lib/chess/ChessEngine';
import ChessBoard from '@/components/chess/ChessBoard';
import { MoveHistory } from '@/components/chess/MoveHistory';
import { GameControls } from '@/components/chess/GameControls';
import { GameTimer } from '@/components/chess/GameTimer';
import { GameStatus } from '@/components/chess/GameStatus';
import GameEndModal from '@/components/chess/GameEndModal';
import GameActionsPanel from '@/components/chess/GameActionsPanel';
import ShareGameLink from '@/components/chess/ShareGameLink';
import { audioManager } from '@/lib/audio/AudioManager';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Loader2, Copy, Check, Share2, Users } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { createOnlineGame, updateOnlineGame, findWaitingGame, subscribeToGame, addGameMove, getGameByCode, getOnlineGame } from '@/db/api';
import type { Position, TimeControl } from '@/types/types';

export default function OnlineGamePage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  const [engine] = useState(() => new ChessEngine());
  const [gameStarted, setGameStarted] = useState(false);
  const [searching, setSearching] = useState(false);
  const [timeControl, setTimeControl] = useState<TimeControl>('blitz');
  const [showHints, setShowHints] = useState(true);
  const [whiteTime, setWhiteTime] = useState(300);
  const [blackTime, setBlackTime] = useState(300);
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [winner, setWinner] = useState<'white' | 'black' | 'draw' | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [gameId, setGameId] = useState<string | null>(null);
  const [gameCode, setGameCode] = useState<string>('');
  const [joinCode, setJoinCode] = useState<string>('');
  const [playerId] = useState(() => `player_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const [playerColor, setPlayerColor] = useState<'white' | 'black'>('white');
  const [showCopied, setShowCopied] = useState(false);
  const [, forceUpdate] = useState({});
  const [gameResult, setGameResult] = useState<'checkmate' | 'draw' | 'resignation' | null>(null);
  const [showGameEndModal, setShowGameEndModal] = useState(false);
  const [pendingDrawOffer, setPendingDrawOffer] = useState(false);
  const [pendingTakebackRequest, setPendingTakebackRequest] = useState(false);
  const [hasAttemptedJoin, setHasAttemptedJoin] = useState(false);
  const [selectedSquare, setSelectedSquare] = useState<Position | null>(null);
  const [validMoves, setValidMoves] = useState<Position[]>([]);

  // Join game with code - defined early for useEffect
  const handleJoinWithCode = useCallback(async (code?: string) => {
    const codeToJoin = code || joinCode;
    if (!codeToJoin) {
      toast({
        title: '⚠️ No Code',
        description: 'Please enter a game code!',
        variant: 'destructive',
      });
      return;
    }

    setSearching(true);
    
    try {
      const game = await getGameByCode(codeToJoin.toUpperCase());
      
      if (!game) {
        toast({
          title: '❌ Game Not Found',
          description: 'Invalid game code. Check and try again!',
          variant: 'destructive',
        });
        setSearching(false);
        return;
      }

      if (game.status !== 'waiting') {
        toast({
          title: '⚠️ Game Unavailable',
          description: 'This game has already started or ended!',
          variant: 'destructive',
        });
        setSearching(false);
        return;
      }

      await updateOnlineGame(game.id, {
        black_player_id: playerId,
        status: 'active',
      });

      engine.fromFEN(game.current_fen);
      setGameId(game.id);
      setPlayerColor('black');
      setWhiteTime(game.white_time_remaining);
      setBlackTime(game.black_time_remaining);
      setGameStarted(true);
      setIsTimerActive(true);
      
      // Auto-scroll to top to show the game board
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      toast({
        title: '⚡ Game Joined!',
        description: 'Let the ninja battle begin! Dattebayo!',
      });
    } catch (error) {
      console.error('Error joining game:', error);
      toast({
        title: '❌ Error',
        description: 'Failed to join game. Try again!',
        variant: 'destructive',
      });
    } finally {
      setSearching(false);
    }
  }, [joinCode, toast, engine, playerId]);

  // Handle URL code parameter for joining games
  useEffect(() => {
    const code = searchParams.get('code');
    if (code && !hasAttemptedJoin && !gameId) {
      setHasAttemptedJoin(true);
      setJoinCode(code);
      handleJoinWithCode(code);
    }
  }, [searchParams, hasAttemptedJoin, gameId, handleJoinWithCode]);

  useEffect(() => {
    audioManager.setSoundEnabled(soundEnabled);
    audioManager.setMusicEnabled(musicEnabled);
  }, [soundEnabled, musicEnabled]);

  useEffect(() => {
    if (!gameId) return;

    console.log('Setting up subscription for game:', gameId);

    const channel = subscribeToGame(gameId, (payload) => {
      console.log('Received game update:', payload);
      
      // Handle all event types (INSERT, UPDATE, DELETE)
      if (payload.eventType === 'UPDATE' || payload.eventType === 'INSERT') {
        const game = payload.new;
        
        if (game.status === 'active' && !gameStarted) {
          console.log('Game is now active, starting game...');
          setGameStarted(true);
          setIsTimerActive(true);
          toast({
            title: '⚡ Game Started!',
            description: 'Your opponent has joined! Let the battle begin! 🍥',
          });
        }
        
        // Update board position if FEN changed
        if (game.current_fen) {
          const currentFen = engine.toFEN();
          console.log('Current FEN:', currentFen);
          console.log('New FEN:', game.current_fen);
          
          if (game.current_fen !== currentFen) {
            console.log('Updating board position from subscription');
            engine.fromFEN(game.current_fen);
            
            // Clear selection when opponent moves
            setSelectedSquare(null);
            setValidMoves([]);
            
            // Force re-render
            forceUpdate({});
            
            // Play move sound
            const state = engine.getState();
            if (state.isCheck) {
              audioManager.playCheck();
            } else {
              audioManager.playMove();
            }
          }
        }

        // Update timers
        setWhiteTime(game.white_time_remaining);
        setBlackTime(game.black_time_remaining);

        if (game.status === 'completed') {
          setWinner(game.winner);
          setIsTimerActive(false);
          
          toast({
            title: '🎮 Game Over!',
            description: game.winner === 'draw' ? '🤝 Game ended in a draw!' : `🏆 ${game.winner} wins! Believe it!`,
          });
        }
      }
    });

    return () => {
      console.log('Unsubscribing from game:', gameId);
      channel.unsubscribe();
    };
  }, [gameId, engine, toast]);

  // Fallback polling mechanism when waiting for opponent
  useEffect(() => {
    if (!gameId || gameStarted) return;

    console.log('Starting polling for game status...');
    
    const pollInterval = setInterval(async () => {
      try {
        const game = await getOnlineGame(gameId);
        if (game && game.status === 'active') {
          console.log('Polling detected game is active!');
          setGameStarted(true);
          setIsTimerActive(true);
          
          // Update game state
          if (game.current_fen) {
            engine.fromFEN(game.current_fen);
            forceUpdate({});
          }
          setWhiteTime(game.white_time_remaining);
          setBlackTime(game.black_time_remaining);
          
          toast({
            title: '⚡ Game Started!',
            description: 'Your opponent has joined! Let the battle begin! 🍥',
          });
        }
      } catch (error) {
        console.error('Error polling game status:', error);
      }
    }, 2000); // Poll every 2 seconds

    return () => {
      console.log('Stopping polling');
      clearInterval(pollInterval);
    };
  }, [gameId, gameStarted, engine, toast]);

  // Continuous polling during active game for move synchronization
  useEffect(() => {
    if (!gameId || !gameStarted) return;

    console.log('Starting continuous polling for move synchronization...');
    let lastFen = engine.toFEN();
    
    const syncInterval = setInterval(async () => {
      try {
        const game = await getOnlineGame(gameId);
        if (game && game.current_fen) {
          const currentFen = engine.toFEN();
          
          // Only update if FEN actually changed and is different from last known FEN
          if (game.current_fen !== currentFen && game.current_fen !== lastFen) {
            console.log('Polling detected FEN change!');
            console.log('Current FEN:', currentFen);
            console.log('New FEN:', game.current_fen);
            
            lastFen = game.current_fen;
            engine.fromFEN(game.current_fen);
            setSelectedSquare(null);
            setValidMoves([]);
            forceUpdate({});
            
            const state = engine.getState();
            if (state.isCheck) {
              audioManager.playCheck();
            } else {
              audioManager.playMove();
            }
          }
          
          // Update timers
          setWhiteTime(game.white_time_remaining);
          setBlackTime(game.black_time_remaining);
          
          // Check for game completion
          if (game.status === 'completed' && !winner) {
            setWinner(game.winner);
            setIsTimerActive(false);
            toast({
              title: '🎮 Game Over!',
              description: game.winner === 'draw' ? '🤝 Game ended in a draw!' : `🏆 ${game.winner} wins! Believe it!`,
            });
          }
        }
      } catch (error) {
        console.error('Error in sync polling:', error);
      }
    }, 2500); // Poll every 2.5 seconds - optimized for performance

    return () => {
      console.log('Stopping sync polling');
      clearInterval(syncInterval);
    };
  }, [gameId, gameStarted, engine, winner, toast]);

  const generateGameCode = () => {
    return Math.random().toString(36).substr(2, 6).toUpperCase();
  };

  const getTimeForControl = (control: TimeControl): number => {
    switch (control) {
      case 'bullet':
        return 60;
      case 'blitz':
        return 300;
      case 'rapid':
        return 600;
      case 'classical':
        return 1800;
      case 'unlimited':
        return 999999;
      default:
        return 300;
    }
  };

  const handleCreatePrivateGame = async () => {
    setSearching(true);
    
    try {
      const code = generateGameCode();
      const initialTime = getTimeForControl(timeControl);
      
      const game = await createOnlineGame({
        white_player_id: playerId,
        black_player_id: null,
        time_control: initialTime,
        game_mode: timeControl,
        white_time_remaining: initialTime,
        black_time_remaining: initialTime,
        current_fen: engine.toFEN(),
        status: 'waiting',
        game_code: code,
      });

      setGameId(game.id);
      setGameCode(code);
      setPlayerColor('white');
      setWhiteTime(initialTime);
      setBlackTime(initialTime);
      setGameStarted(false);
      
      // Auto-scroll to top to show the game board
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      toast({
        title: '🎮 Private Game Created!',
        description: `Share code ${code} with your friend! 🍥`,
      });
    } catch (error) {
      toast({
        title: '❌ Error',
        description: 'Failed to create game. Try again!',
        variant: 'destructive',
      });
    } finally {
      setSearching(false);
    }
  };

  const handleFindGame = async () => {
    setSearching(true);
    
    try {
      const existingGame = await findWaitingGame(timeControl);
      
      if (existingGame) {
        await updateOnlineGame(existingGame.id, {
          black_player_id: playerId,
          status: 'active',
        });

        engine.fromFEN(existingGame.current_fen);
        setGameId(existingGame.id);
        setPlayerColor('black');
        setWhiteTime(existingGame.white_time_remaining);
        setBlackTime(existingGame.black_time_remaining);
        setGameStarted(true);
        setIsTimerActive(true);
        
        // Auto-scroll to top to show the game board
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        toast({
          title: '⚡ Opponent Found!',
          description: 'Game starting now! Good luck!',
        });
      } else {
        const initialTime = getTimeForControl(timeControl);
        
        const game = await createOnlineGame({
          white_player_id: playerId,
          black_player_id: null,
          time_control: initialTime,
          game_mode: timeControl,
          white_time_remaining: initialTime,
          black_time_remaining: initialTime,
          current_fen: engine.toFEN(),
          status: 'waiting',
        });

        setGameId(game.id);
        setPlayerColor('white');
        setWhiteTime(initialTime);
        setBlackTime(initialTime);
        
        // Auto-scroll to top to show waiting state
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        toast({
          title: '🔍 Searching...',
          description: 'Waiting for an opponent to join...',
        });
      }
    } catch (error) {
      toast({
        title: '❌ Error',
        description: 'Failed to find game. Try again!',
        variant: 'destructive',
      });
      setSearching(false);
    }
  };

  const handleMove = useCallback(
    async (from: Position, to: Position) => {
      if (winner || !gameId) return;
      if (engine.getState().currentTurn !== playerColor) {
        console.log('Not your turn! Current turn:', engine.getState().currentTurn, 'Your color:', playerColor);
        return;
      }

      console.log('Attempting move from', from, 'to', to);
      const success = engine.makeMove(from, to);
      
      if (success) {
        const newFen = engine.toFEN();
        const state = engine.getState();
        
        console.log('Move successful! New FEN:', newFen);
        
        // Clear selection after move
        setSelectedSquare(null);
        setValidMoves([]);
        
        // Update database
        try {
          await updateOnlineGame(gameId, {
            current_fen: newFen,
            white_time_remaining: whiteTime,
            black_time_remaining: blackTime,
          });
          console.log('Database updated successfully');

          await addGameMove({
            game_id: gameId,
            move_number: state.moveHistory.length,
            from_square: `${String.fromCharCode(97 + from.col)}${8 - from.row}`,
            to_square: `${String.fromCharCode(97 + to.col)}${8 - to.row}`,
          });
          console.log('Move added to history');
        } catch (error) {
          console.error('Error updating database:', error);
        }

        if (state.isCheckmate) {
          const winnerColor = state.currentTurn === 'white' ? 'black' : 'white';
          setWinner(winnerColor);
          setGameResult('checkmate');
          setIsTimerActive(false);
          setShowGameEndModal(true);
          await updateOnlineGame(gameId, {
            status: 'completed',
            winner: winnerColor,
          });
          audioManager.playCheckmate();
        } else if (state.isCheck) {
          audioManager.playCheck();
        } else {
          audioManager.playMove();
        }

        forceUpdate({});
      } else {
        console.log('Move failed - invalid move');
      }
    },
    [engine, winner, gameId, playerColor, whiteTime, blackTime]
  );

  const handleSquareClick = useCallback(
    (pos: Position) => {
      if (winner || !gameId) return;
      if (engine.getState().currentTurn !== playerColor) return;

      const piece = engine.getState().board[pos.row][pos.col];
      
      // Only allow selecting own pieces
      if (piece && piece.color === playerColor) {
        setSelectedSquare(pos);
        const moves = showHints ? engine.getLegalMoves(pos) : [];
        setValidMoves(moves);
      }
    },
    [engine, winner, gameId, playerColor, showHints]
  );

  const copyGameLink = () => {
    const link = `${window.location.origin}/game/online?code=${gameCode}`;
    navigator.clipboard.writeText(link);
    setShowCopied(true);
    setTimeout(() => setShowCopied(false), 2000);
    toast({
      title: '✅ Link Copied!',
      description: 'Share this link with your friend!',
    });
  };

  const copyGameCode = () => {
    navigator.clipboard.writeText(gameCode);
    setShowCopied(true);
    setTimeout(() => setShowCopied(false), 2000);
    toast({
      title: '✅ Code Copied!',
      description: 'Share this code with your friend!',
    });
  };

  const handleResign = async () => {
    if (!gameId) return;
    
    const winnerColor = playerColor === 'white' ? 'black' : 'white';
    setWinner(winnerColor);
    setGameResult('resignation');
    setIsTimerActive(false);
    setShowGameEndModal(true);
    
    await updateOnlineGame(gameId, {
      status: 'completed',
      winner: winnerColor,
    });

    toast({
      title: '🏳️ Game Resigned',
      description: `${winnerColor === 'white' ? 'White' : 'Black'} wins!`,
    });
  };

  const handleOfferDraw = async () => {
    if (!gameId) return;
    
    setPendingDrawOffer(true);
    toast({
      title: '🤝 Draw Offer Sent',
      description: 'Waiting for opponent response...',
    });
  };

  const handleAcceptDraw = async () => {
    if (!gameId) return;
    
    setWinner('draw');
    setGameResult('draw');
    setIsTimerActive(false);
    setShowGameEndModal(true);
    setPendingDrawOffer(false);
    
    await updateOnlineGame(gameId, {
      status: 'completed',
      winner: 'draw',
    });

    toast({
      title: '🤝 Draw Accepted',
      description: 'Game ended in a draw!',
    });
  };

  const handleDeclineDraw = () => {
    setPendingDrawOffer(false);
    toast({
      title: '❌ Draw Declined',
      description: 'The game continues!',
    });
  };

  const handleRequestTakeback = () => {
    setPendingTakebackRequest(true);
    toast({
      title: '⏪ Takeback Requested',
      description: 'Waiting for opponent approval...',
    });
  };

  const handleAcceptTakeback = () => {
    engine.undoMove();
    forceUpdate({});
    setPendingTakebackRequest(false);
    toast({
      title: '✅ Takeback Accepted',
      description: 'Move has been undone!',
    });
  };

  const handleDeclineTakeback = () => {
    setPendingTakebackRequest(false);
    toast({
      title: '❌ Takeback Declined',
      description: 'Request was denied.',
    });
  };

  const handleNewGame = () => {
    setGameStarted(false);
    setGameId(null);
    setGameCode('');
    setWinner(null);
    setGameResult(null);
    setShowGameEndModal(false);
    setPendingDrawOffer(false);
    setPendingTakebackRequest(false);
    forceUpdate({});
  };

  if (!gameStarted && !gameId) {
    return (
      <div 
        className="min-h-screen p-4 xl:p-8 relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, hsl(var(--background)) 0%, hsl(var(--muted)) 50%, hsl(var(--background)) 100%)',
        }}
      >
        <div className="absolute inset-0 leaf-pattern opacity-20" />
        <div className="absolute top-20 left-10 w-32 h-32 bg-secondary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        
        {/* Floating Naruto Elements */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute text-4xl animate-float opacity-30"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${i * 0.5}s`,
                animationDuration: `${4 + Math.random() * 3}s`,
              }}
            >
              {['🍥', '🥷', '⚡', '🔥', '💨', '🌀'][i]}
            </div>
          ))}
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate('/')}
            className="mb-6 ninja-button"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Menu
          </Button>

          <Card className="anime-card rounded-3xl overflow-hidden bg-white/95 dark:bg-slate-900/95 shadow-2xl border-4 border-orange-200 dark:border-orange-900/30 cartoon-card bounce-in">
            <CardHeader className="text-center relative overflow-hidden px-4 py-6 xl:px-6 xl:py-8">
              {/* Smooth Flowing Background */}
              <div className="absolute inset-0 sunset-gradient opacity-20" />
              
              {/* Floating particles */}
              <div className="absolute inset-0 pointer-events-none overflow-hidden">
                {[...Array(12)].map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-2 h-2 rounded-full bg-orange-400 ember-float"
                    style={{
                      left: `${(i * 10) % 100}%`,
                      bottom: '0',
                      animationDelay: `${i * 0.3}s`,
                      animationDuration: `${3 + i * 0.4}s`
                    }}
                  />
                ))}
              </div>
              
              <div className="relative z-10">
                <div className="flex items-center justify-center mb-4">
                  <div className="ninja-gradient w-16 h-16 xl:w-20 xl:h-20 rounded-3xl flex items-center justify-center gentle-glow shadow-lg wiggle-hover">
                    <Users className="w-8 h-8 xl:w-10 xl:h-10 text-white drop-shadow-lg" strokeWidth={3} />
                  </div>
                </div>
                <CardTitle className="text-3xl xl:text-5xl font-black mb-2 xl:mb-3 px-2">
                  <span className="bg-gradient-to-r from-orange-500 via-amber-500 to-orange-500 bg-clip-text text-transparent rainbow-hover">
                    🌐 ONLINE ARENA
                  </span>
                </CardTitle>
                <p className="text-base xl:text-xl font-bold text-orange-600 dark:text-orange-400 px-2">
                  Battle ninjas from around the world! 🍥
                </p>
              </div>
            </CardHeader>
            <CardContent className="space-y-4 xl:space-y-6 relative px-4 py-6 xl:px-6 xl:py-8">
              <div className="space-y-4 relative z-10">
                <div>
                  <Label className="text-base xl:text-xl font-black mb-2 xl:mb-3 flex items-center gap-2 text-orange-600 dark:text-orange-400">
                    <span className="text-2xl xl:text-3xl wiggle-hover inline-block">⏱️</span>
                    <span>Time Control</span>
                  </Label>
                  <Select value={timeControl} onValueChange={(v) => setTimeControl(v as TimeControl)}>
                    <SelectTrigger className="text-base xl:text-lg font-bold border-3 sunset-border rounded-2xl h-14 xl:h-16 ninja-gradient text-white shadow-lg gentle-glow cartoon-button">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="border-3 border-orange-200 dark:border-orange-900/50">
                      <SelectItem value="bullet" className="text-base xl:text-lg font-bold py-3 xl:py-4 cartoon-button">⚡ Bullet (1 min)</SelectItem>
                      <SelectItem value="blitz" className="text-base xl:text-lg font-bold py-3 xl:py-4 cartoon-button">🔥 Blitz (5 min)</SelectItem>
                      <SelectItem value="rapid" className="text-base xl:text-lg font-bold py-3 xl:py-4 cartoon-button">⏰ Rapid (10 min)</SelectItem>
                      <SelectItem value="classical" className="text-base xl:text-lg font-bold py-3 xl:py-4 cartoon-button">👑 Classical (30 min)</SelectItem>
                      <SelectItem value="unlimited" className="text-base xl:text-lg font-bold py-3 xl:py-4 cartoon-button">♾️ Unlimited</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 xl:gap-4">
                  <div className="flex items-center justify-between p-4 xl:p-5 rounded-2xl sunset-gradient glass-effect shadow-lg gentle-glow cartoon-card">
                    <Label className="font-black text-base xl:text-lg text-white flex items-center gap-2 drop-shadow-lg">
                      <span className="text-xl xl:text-2xl wiggle-hover inline-block">🔊</span> 
                      <span className="hidden sm:inline">Sound Effects</span>
                      <span className="sm:hidden">Sound</span>
                    </Label>
                    <Switch checked={soundEnabled} onCheckedChange={setSoundEnabled} className="scale-110 xl:scale-125" />
                  </div>
                  <div className="flex items-center justify-between p-4 xl:p-5 rounded-2xl twilight-gradient glass-effect shadow-lg gentle-glow cartoon-card">
                    <Label className="font-black text-base xl:text-lg text-white flex items-center gap-2 drop-shadow-lg">
                      <span className="text-xl xl:text-2xl wiggle-hover inline-block">🎵</span> 
                      <span className="hidden sm:inline">Background Music</span>
                      <span className="sm:hidden">Music</span>
                    </Label>
                    <Switch checked={musicEnabled} onCheckedChange={setMusicEnabled} className="scale-110 xl:scale-125" />
                  </div>
                </div>
              </div>

              <div className="space-y-3 xl:space-y-4 relative z-10">
                <Button
                  type="button"
                  onClick={handleFindGame}
                  disabled={searching}
                  className="w-full text-lg xl:text-2xl py-6 xl:py-10 rounded-2xl font-black ninja-gradient text-white shadow-2xl cartoon-button gentle-glow border-0"
                  size="lg"
                >
                  {searching ? (
                    <>
                      <Loader2 className="w-6 h-6 xl:w-8 xl:h-8 mr-2 xl:mr-3 animate-spin drop-shadow-lg" strokeWidth={3} />
                      <span className="hidden sm:inline">SEARCHING FOR OPPONENT...</span>
                      <span className="sm:hidden">SEARCHING...</span>
                    </>
                  ) : (
                    <>
                      <Users className="w-6 h-6 xl:w-8 xl:h-8 mr-2 xl:mr-3 drop-shadow-lg wiggle-hover inline-block" strokeWidth={3} />
                      <span className="hidden sm:inline">FIND RANDOM MATCH</span>
                      <span className="sm:hidden">FIND MATCH</span>
                    </>
                  )}
                </Button>

                <div className="relative py-2">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t-3 border-orange-200 dark:border-orange-900/30" />
                  </div>
                  <div className="relative flex justify-center text-base">
                    <span className="px-4 xl:px-6 py-1 xl:py-2 bg-white dark:bg-slate-900 font-black text-lg xl:text-xl rounded-full border-3 sunset-border shadow-lg text-orange-600 dark:text-orange-400 pop-hover">OR</span>
                  </div>
                </div>

                <Button
                  type="button"
                  onClick={handleCreatePrivateGame}
                  disabled={searching}
                  variant="secondary"
                  className="w-full text-lg xl:text-2xl py-6 xl:py-10 rounded-2xl font-black twilight-gradient text-white shadow-2xl cartoon-button gentle-glow border-0"
                  size="lg"
                >
                  <Share2 className="w-6 h-6 xl:w-8 xl:h-8 mr-2 xl:mr-3 drop-shadow-lg wiggle-hover inline-block" strokeWidth={3} />
                  <span className="hidden sm:inline">CREATE PRIVATE GAME</span>
                  <span className="sm:hidden">PRIVATE GAME</span>
                </Button>

                <div className="space-y-3 p-4 xl:p-6 rounded-2xl dawn-gradient glass-effect shadow-lg sunset-border cartoon-card">
                  <Label className="text-base xl:text-xl font-black text-white flex items-center gap-2 drop-shadow-lg">
                    <span className="text-2xl xl:text-3xl wiggle-hover inline-block">🎯</span> Join with Code
                  </Label>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Input
                      placeholder="Enter code..."
                      value={joinCode}
                      onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                      className="text-lg xl:text-xl font-black border-3 sunset-border uppercase rounded-xl h-12 xl:h-14 bg-white/90 dark:bg-slate-800/90 text-orange-600 dark:text-orange-400 placeholder:text-orange-300 dark:placeholder:text-orange-700 shadow-lg flex-1 cartoon-button"
                      maxLength={6}
                    />
                    <Button
                      type="button"
                      onClick={() => handleJoinWithCode()}
                      disabled={!joinCode || searching}
                      className="font-black text-base xl:text-lg px-6 xl:px-8 h-12 xl:h-14 rounded-xl sunset-gradient text-white shadow-lg cartoon-button gentle-glow border-0 w-full sm:w-auto"
                      size="lg"
                    >
                      JOIN
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (gameId && !gameStarted) {
    return (
      <div 
        className="min-h-screen p-4 xl:p-8 flex items-center justify-center relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, hsl(var(--background)) 0%, hsl(var(--muted)) 50%, hsl(var(--background)) 100%)',
        }}
      >
        <div className="absolute inset-0 leaf-pattern opacity-20" />
        
        <Card className="anime-card rounded-3xl border-4 max-w-2xl w-full relative z-10">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center mb-4">
              <Loader2 className="w-16 h-16 text-primary animate-spin" />
            </div>
            <CardTitle className="text-3xl font-black">
              {gameCode ? '🎮 Waiting for Friend...' : '🔍 Finding Opponent...'}
            </CardTitle>
            <p className="text-lg font-bold text-muted-foreground mt-2">
              {gameCode ? 'Share the code below with your friend!' : 'Hang tight! This won\'t take long!'}
            </p>
          </CardHeader>
          {gameCode && (
            <CardContent className="space-y-4">
              <ShareGameLink gameCode={gameCode} />
            </CardContent>
          )}
        </Card>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen p-1 xl:p-8 relative overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, hsl(var(--background)) 0%, hsl(var(--muted)) 50%, hsl(var(--background)) 100%)',
      }}
    >
      <div className="absolute inset-0 leaf-pattern opacity-20" />
      
      {/* Floating Naruto Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute text-3xl xl:text-5xl animate-float opacity-20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.7}s`,
              animationDuration: `${5 + Math.random() * 4}s`,
            }}
          >
            {['🍥', '🥷', '⚡', '🔥', '💨', '🌀', '🍜', '⭐'][i]}
          </div>
        ))}
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-1 xl:mb-6 px-1">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate('/')}
            className="ninja-button font-black text-xs xl:text-sm"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Leave Game
          </Button>
          {gameCode && (
            <div className="flex items-center gap-2 px-2 xl:px-4 py-1 xl:py-2 rounded-xl bg-primary/10 border-2 border-primary/30">
              <span className="text-xs xl:text-sm font-black text-muted-foreground">CODE:</span>
              <span className="text-lg xl:text-xl font-black text-primary">{gameCode}</span>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                onClick={copyGameCode}
                className="h-8 w-8 p-0"
              >
                {showCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-1 xl:gap-6">
          <div className="xl:col-span-2 space-y-1 xl:space-y-6">
            <GameStatus
              gameState={engine.getState()}
              gameMode="online"
              winner={winner}
            />
            <ChessBoard
              board={engine.getState().board}
              onMove={handleMove}
              validMoves={validMoves}
              selectedSquare={selectedSquare}
              onSquareClick={handleSquareClick}
              isFlipped={playerColor === 'black'}
            />
          </div>

          <div className="space-y-1 xl:space-y-6">
            <GameTimer
              whiteTime={whiteTime}
              blackTime={blackTime}
              currentTurn={engine.getState().currentTurn}
              isActive={isTimerActive}
              onTimeOut={(color) => {
                setWinner(color === 'white' ? 'black' : 'white');
                setGameResult('checkmate');
                setIsTimerActive(false);
                setShowGameEndModal(true);
                if (gameId) {
                  updateOnlineGame(gameId, {
                    status: 'completed',
                    winner: color === 'white' ? 'black' : 'white',
                  });
                }
              }}
            />
            <GameActionsPanel
              onResign={handleResign}
              onOfferDraw={handleOfferDraw}
              onRequestTakeback={handleRequestTakeback}
              showTakeback={true}
              isOnline={true}
              pendingDrawOffer={pendingDrawOffer}
              pendingTakebackRequest={pendingTakebackRequest}
              onAcceptDraw={handleAcceptDraw}
              onDeclineDraw={handleDeclineDraw}
              onAcceptTakeback={handleAcceptTakeback}
              onDeclineTakeback={handleDeclineTakeback}
            />
            <MoveHistory moves={engine.getState().moveHistory} />
          </div>
        </div>

        {/* Game End Modal */}
        <GameEndModal
          isOpen={showGameEndModal}
          result={gameResult}
          winner={winner}
          onNewGame={handleNewGame}
        />
      </div>
    </div>
  );
}
