import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bot, Users, Gamepad2, Sparkles, Zap, Crown, Target, Clock, Share2, Timer, Star } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function HomePage() {
  const navigate = useNavigate();
  const heroSection = useScrollAnimation();
  const gameModeSection = useScrollAnimation();
  const localBattleSection = useScrollAnimation();
  const featuresSection = useScrollAnimation();
  const charactersSection = useScrollAnimation();

  // Handle navigation with auto-scroll to top
  const handleNavigate = (path: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    navigate(path);
  };

  const gameModes = [
    {
      title: 'Multiplayer',
      description: 'Battle your friends! Share a code and play together in real-time with custom timers!',
      icon: Users,
      path: '/game/online',
      emoji: '🎮',
      color: 'from-orange-400 via-pink-400 to-purple-500',
      bgGradient: 'from-orange-100/90 via-pink-100/90 to-purple-100/90 dark:from-orange-900/30 dark:via-pink-900/30 dark:to-purple-900/30',
      badges: [
        { icon: Zap, text: 'Real-time', color: 'from-orange-400 via-yellow-400 to-orange-500' },
        { icon: Share2, text: 'Shareable', color: 'from-purple-400 via-pink-400 to-purple-500' },
        { icon: Timer, text: 'Custom Timer', color: 'from-pink-400 via-purple-400 to-pink-500' },
      ],
    },
    {
      title: 'AI Training',
      description: 'Master your skills against intelligent AI opponents! Choose your challenge level!',
      icon: Bot,
      path: '/game/ai',
      emoji: '🤖',
      color: 'from-blue-400 via-cyan-400 to-teal-500',
      bgGradient: 'from-blue-100/90 via-cyan-100/90 to-teal-100/90 dark:from-blue-900/30 dark:via-cyan-900/30 dark:to-teal-900/30',
      badges: [
        { icon: Target, text: 'Easy', color: 'from-green-400 via-emerald-400 to-teal-500' },
        { icon: Target, text: 'Medium', color: 'from-blue-400 via-indigo-400 to-purple-500' },
        { icon: Target, text: 'Hard', color: 'from-red-400 via-rose-400 to-pink-500' },
      ],
    },
  ];

  const features = [
    {
      icon: Crown,
      title: 'Naruto Characters',
      description: 'Play with iconic characters as chess pieces',
      color: 'from-orange-400 to-red-500',
    },
    {
      icon: Target,
      title: 'Multiple Difficulty Levels',
      description: 'From beginner to expert AI opponents',
      color: 'from-blue-400 to-purple-500',
    },
    {
      icon: Clock,
      title: 'Time Controls',
      description: 'Bullet, Blitz, Rapid, or Classical modes',
      color: 'from-purple-400 to-pink-500',
    },
    {
      icon: Sparkles,
      title: 'Beautiful Animations',
      description: 'Smooth effects and ninja-themed visuals',
      color: 'from-green-400 to-teal-500',
    },
  ];

  return (
    <div className="min-h-screen relative overflow-hidden dual-tone-flow">
      {/* Cute Floating Clouds Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-br from-orange-500/30 to-blue-500/30 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-[500px] h-[500px] bg-gradient-to-br from-blue-600/30 to-orange-600/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/3 w-80 h-80 bg-gradient-to-br from-orange-400/20 to-blue-400/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
        
        {/* Floating Stars */}
        {[...Array(8)].map((_, i) => (
          <Star
            key={i}
            className="absolute text-yellow-300 sparkle-effect"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: `${20 + Math.random() * 20}px`,
              height: `${20 + Math.random() * 20}px`,
              animationDelay: `${i * 0.3}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-8 xl:py-16">
        {/* Ultra-Cartoonish Hero Section */}
        <div ref={heroSection.ref} className={`text-center mb-12 xl:mb-16 transition-all duration-1000 ${heroSection.isVisible ? 'scroll-fade-in' : 'opacity-0'}`}>
          {/* Cute Ninja Village Background Image */}
          <div className="mb-8 relative">
            <img 
              src="https://miaoda-site-img.s3cdn.medo.dev/images/7c08b154-bbe0-4f3e-a4ad-edaaf7ff61a3.jpg"
              alt="Ninja Village"
              className="w-full max-w-4xl mx-auto rounded-[3rem] shadow-2xl border-8 border-white/50 object-cover h-48 xl:h-64 pop-in"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent rounded-[3rem]" />
          </div>

          {/* Playful Logo */}
          <div className="mb-6 bounce-in">
            <div className="inline-block mb-4">
              <img 
                src="https://miaoda-site-img.s3cdn.medo.dev/images/557d8e30-1d17-495e-a352-a62bfe711637.jpg"
                alt="Ninja Chess Logo"
                className="w-32 h-32 xl:w-40 xl:h-40 mx-auto rounded-full border-8 border-primary shadow-2xl object-cover wiggle-fun chakra-pulse"
                loading="eager"
              />
            </div>
            <div className="flex items-center justify-center gap-4 mb-4">
              <span className="text-5xl xl:text-6xl animate-bounce">🥷</span>
              <h2 className="text-5xl xl:text-7xl font-black" style={{
                textShadow: '4px 4px 0 hsl(var(--foreground)), 6px 6px 20px rgba(0,0,0,0.3)'
              }}>
                <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                  NINJA CHESS
                </span>
              </h2>
              <span className="text-5xl xl:text-6xl animate-bounce" style={{ animationDelay: '0.3s' }}>🥷</span>
            </div>
            <div className="flex items-center justify-center gap-3 text-xl xl:text-2xl font-black italic">
              <Sparkles className="w-6 h-6 text-primary animate-pulse" />
              <span className="bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">
                Where Strategy Meets Ninja Magic!
              </span>
              <Sparkles className="w-6 h-6 text-accent animate-pulse" style={{ animationDelay: '0.5s' }} />
            </div>
          </div>

          {/* Cute Chibi Ninjas */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <img 
              src="https://miaoda-site-img.s3cdn.medo.dev/images/810c4699-a57b-44c5-a770-b5c44d759a51.jpg"
              alt="Chibi Ninjas"
              className="w-full max-w-2xl rounded-[2rem] border-6 border-white/50 shadow-2xl object-cover h-32 xl:h-48 pop-in"
              style={{ animationDelay: '0.3s' }}
              loading="lazy"
            />
          </div>
        </div>

        {/* Cartoonish Game Mode Cards - PHENOMENAL EDITION - MOBILE OPTIMIZED */}
        <div ref={gameModeSection.ref} className={`grid grid-cols-1 xl:grid-cols-2 gap-6 xl:gap-8 mb-12 max-w-6xl mx-auto px-2 transition-all duration-1000 ${gameModeSection.isVisible ? 'scroll-zoom-in' : 'opacity-0'}`}>
          {gameModes.map((mode, index) => {
            const Icon = mode.icon;
            return (
              <div
                key={mode.path}
                className="bouncy-card cursor-pointer pop-in cartoon-card relative overflow-hidden group transform transition-all duration-500 hover:scale-105"
                onClick={() => handleNavigate(mode.path)}
                style={{
                  background: `linear-gradient(135deg, hsl(var(--card)) 0%, hsl(var(--muted)) 100%)`,
                  animationDelay: `${index * 0.2}s`,
                  boxShadow: '0 25px 70px rgba(0,0,0,0.2), 0 10px 30px rgba(255,165,0,0.3), inset 0 1px 0 rgba(255,255,255,0.3)',
                  border: '3px solid rgba(255,255,255,0.2)',
                }}
              >
                {/* Magical Particle Effects - Optimized */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden">
                  {[...Array(12)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute w-2 h-2 xl:w-3 xl:h-3 rounded-full bg-gradient-to-r from-orange-400 via-pink-400 to-purple-400 ember-float opacity-70"
                      style={{
                        left: `${(i * 9) % 100}%`,
                        bottom: '-10px',
                        animationDelay: `${i * 0.2}s`,
                        animationDuration: `${2 + i * 0.2}s`,
                        filter: 'blur(1px)',
                        willChange: 'transform',
                      }}
                    />
                  ))}
                </div>

                {/* Animated gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <CardContent className="p-6 xl:p-12 relative z-10">
                  <div className="text-center space-y-5 xl:space-y-8">
                    {/* Huge Cartoonish Icon with Dual-Tone Gradient Background */}
                    <div className="relative mx-auto w-32 h-32 xl:w-56 xl:h-56 mb-5 xl:mb-8 transform transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3">
                      {/* Outer glow effect */}
                      <div 
                        className={`absolute -inset-4 bg-gradient-to-br ${mode.color} rounded-[3rem] xl:rounded-[5rem] blur-2xl opacity-60 animate-pulse`}
                      />
                      
                      {/* Dual-tone gradient background with rounded corners */}
                      <div 
                        className={`absolute inset-0 bg-gradient-to-br ${mode.color} rounded-[2.5rem] xl:rounded-[4.5rem] shadow-2xl transform transition-transform duration-500`}
                        style={{
                          boxShadow: '0 25px 70px rgba(0,0,0,0.4), inset 0 -3px 15px rgba(0,0,0,0.3), inset 0 3px 15px rgba(255,255,255,0.2)',
                        }}
                      />
                      
                      {/* Glossy overlay effect */}
                      <div className="absolute inset-0 bg-gradient-to-b from-white/40 via-transparent to-black/20 rounded-[2.5rem] xl:rounded-[4.5rem]" />
                      
                      {/* Shine effect */}
                      <div className="absolute inset-0 bg-gradient-to-br from-white/30 via-transparent to-transparent rounded-[2.5rem] xl:rounded-[4.5rem] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                      
                      {/* Icon container */}
                      <div className="relative w-full h-full flex items-center justify-center">
                        <Icon className="w-16 h-16 xl:w-32 xl:h-32 text-white drop-shadow-[0_6px_25px_rgba(0,0,0,0.5)] transform transition-transform duration-500 group-hover:scale-110" strokeWidth={2.5} />
                      </div>
                    </div>

                    {/* Title with MEGA Emoji */}
                    <div>
                      <div className="flex items-center justify-center gap-3 xl:gap-5 mb-4 xl:mb-5">
                        <span className="text-5xl xl:text-8xl wiggle-hover inline-block transform transition-transform duration-300 hover:scale-125">{mode.emoji}</span>
                        <h3 className="text-4xl xl:text-6xl font-black rainbow-hover" style={{
                          textShadow: '4px 4px 0 hsl(var(--foreground) / 0.15), 0 0 30px rgba(255,165,0,0.6)'
                        }}>
                          <span className={`bg-gradient-to-r ${mode.color} bg-clip-text text-transparent`}>
                            {mode.title}
                          </span>
                        </h3>
                        <span className="text-5xl xl:text-8xl wiggle-hover inline-block transform transition-transform duration-300 hover:scale-125" style={{ animationDelay: '0.3s' }}>{mode.emoji}</span>
                      </div>
                      <p className="text-lg xl:text-2xl font-bold px-3 xl:px-6 leading-relaxed" style={{
                        textShadow: '2px 2px 4px rgba(0,0,0,0.15)'
                      }}>
                        {mode.description}
                      </p>
                    </div>

                    {/* MEGA Cute Badges - Dual-Tone Gradients! */}
                    <div className="flex flex-wrap items-center justify-center gap-3 xl:gap-5 pt-5 xl:pt-8">
                      {mode.badges.map((badge, idx) => {
                        const BadgeIcon = badge.icon;
                        return (
                          <div
                            key={idx}
                            className={`flex items-center gap-2 xl:gap-3 px-5 py-2.5 xl:px-7 xl:py-4 rounded-full font-bold text-base xl:text-xl shadow-xl hover:scale-110 transition-all duration-300 bg-gradient-to-r ${badge.color} transform hover:-translate-y-1`}
                            style={{
                              color: 'white',
                              textShadow: '2px 2px 4px rgba(0,0,0,0.6)',
                              boxShadow: '0 10px 25px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.3)',
                            }}
                          >
                            <BadgeIcon className="w-5 h-5 xl:w-7 xl:h-7" strokeWidth={2.5} />
                            <span>{badge.text}</span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Hover Glow Effect */}
                    <div className="absolute inset-0 bg-gradient-to-r from-orange-400/0 via-pink-400/0 to-purple-400/0 group-hover:from-orange-400/15 group-hover:via-pink-400/15 group-hover:to-purple-400/15 transition-all duration-500 rounded-3xl pointer-events-none" />
                  </div>
                </CardContent>
              </div>
            );
          })}
        </div>

        {/* Local Battle Card - MEGA Cartoonish - MOBILE OPTIMIZED */}
        <div ref={localBattleSection.ref} className={`max-w-3xl mx-auto mb-12 px-2 transition-all duration-1000 ${localBattleSection.isVisible ? 'scroll-slide-left' : 'opacity-0'}`}>
          <div
            className="bouncy-card cursor-pointer pop-in cartoon-card relative overflow-hidden group"
            onClick={() => handleNavigate('/game/local')}
            style={{
              background: 'linear-gradient(135deg, hsl(var(--card)) 0%, hsl(var(--muted)) 100%)',
              animationDelay: '0.4s',
              boxShadow: '0 20px 60px rgba(0,0,0,0.15), 0 0 40px rgba(138,43,226,0.2)',
            }}
          >
            {/* Sparkle Effects */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              {[...Array(10)].map((_, i) => (
                <Star
                  key={i}
                  className="absolute text-yellow-400 sparkle-effect"
                  style={{
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                    width: `${10 + Math.random() * 10}px`,
                    height: `${10 + Math.random() * 10}px`,
                    animationDelay: `${i * 0.2}s`,
                  }}
                />
              ))}
            </div>

            <CardContent className="p-5 xl:p-10 relative z-10">
              <div className="flex flex-col xl:flex-row items-center justify-between gap-4 xl:gap-6">
                <div className="flex items-center gap-4 xl:gap-8 w-full xl:w-auto">
                  <div className="relative flex-shrink-0">
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full blur-xl xl:blur-2xl opacity-60 animate-pulse" />
                    <div className="cartoon-button holographic shimmer-effect w-16 h-16 xl:w-28 xl:h-28 flex items-center justify-center neon-glow wiggle-hover rainbow-hover relative" style={{
                      color: 'white'
                    }}>
                      <Gamepad2 className="w-8 h-8 xl:w-14 xl:h-14 text-white drop-shadow-[0_0_15px_rgba(255,255,255,1)]" strokeWidth={3.5} />
                    </div>
                    <div className="absolute inset-0 border-2 xl:border-4 border-dashed border-purple-400 rounded-full animate-spin-slow opacity-40" />
                  </div>
                  <div className="text-left flex-1">
                    <h3 className="text-2xl xl:text-4xl font-black mb-1 xl:mb-2 gradient-rotate rainbow-hover" style={{
                      textShadow: '2px 2px 0 hsl(var(--foreground) / 0.1), 0 0 15px rgba(138,43,226,0.4)'
                    }}>
                      <span className="bg-gradient-to-r from-purple-500 via-pink-500 to-purple-500 bg-clip-text text-transparent">
                        🎮 Local Battle
                      </span>
                    </h3>
                    <p className="text-sm xl:text-lg font-black" style={{
                      textShadow: '1px 1px 2px rgba(0,0,0,0.1)'
                    }}>
                      Play with a friend on the same device!
                    </p>
                  </div>
                </div>
                <Button
                  className="cartoon-button holographic shimmer-effect text-white font-black px-6 py-4 xl:px-10 xl:py-8 text-base xl:text-2xl vibrant-pulse wiggle-hover shadow-2xl border-3 xl:border-4 border-white/50 w-full xl:w-auto"
                  size="lg"
                >
                  <Zap className="w-5 h-5 xl:w-7 xl:h-7 mr-2 xl:mr-3" strokeWidth={3.5} />
                  PLAY NOW
                </Button>
              </div>
            </CardContent>
          </div>
        </div>

        {/* Features Section - ULTRA Colorful - MOBILE OPTIMIZED */}
        <div ref={featuresSection.ref} className={`mb-12 px-2 transition-all duration-1000 ${featuresSection.isVisible ? 'scroll-slide-right' : 'opacity-0'}`}>
          <h2 className="text-3xl xl:text-6xl font-black text-center mb-8 xl:mb-12 rainbow-hover px-2" style={{
            textShadow: '4px 4px 0 hsl(var(--foreground) / 0.1), 0 0 30px rgba(255,165,0,0.3)'
          }}>
            <span className="bg-gradient-to-r from-orange-500 via-pink-500 to-purple-500 bg-clip-text text-transparent">
              ⭐✨ AMAZING FEATURES ✨⭐
            </span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 xl:gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="bouncy-card pop-in cartoon-card relative overflow-hidden group"
                  style={{
                    background: 'linear-gradient(135deg, hsl(var(--card)) 0%, hsl(var(--muted)) 100%)',
                    animationDelay: `${index * 0.1}s`,
                    boxShadow: '0 15px 40px rgba(0,0,0,0.12)',
                  }}
                >
                  {/* Floating Particles */}
                  <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    {[...Array(8)].map((_, i) => (
                      <div
                        key={i}
                        className="absolute w-2 h-2 rounded-full bg-gradient-to-r from-orange-400 to-pink-400 ember-float"
                        style={{
                          left: `${(i * 15) % 100}%`,
                          bottom: '-5px',
                          animationDelay: `${i * 0.15}s`,
                          animationDuration: `${2 + i * 0.15}s`
                        }}
                      />
                    ))}
                  </div>

                  <CardContent className="p-6 xl:p-8 text-center space-y-4 xl:space-y-5 relative z-10">
                    <div className="relative mx-auto w-16 h-16 xl:w-24 xl:h-24">
                      <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} rounded-full blur-lg xl:blur-xl opacity-60 animate-pulse`} />
                      <div className={`mx-auto w-full h-full rounded-full bg-gradient-to-br ${feature.color} flex items-center justify-center shadow-2xl border-3 xl:border-4 border-white/70 gradient-rotate neon-glow wiggle-hover rainbow-hover`}>
                        <Icon className="w-8 h-8 xl:w-12 xl:h-12 text-white drop-shadow-[0_0_12px_rgba(255,255,255,1)]" strokeWidth={3.5} />
                      </div>
                      <div className="absolute inset-0 border-2 xl:border-3 border-dashed border-orange-300 rounded-full animate-spin-slow opacity-30" />
                    </div>
                    <h3 className="font-black text-lg xl:text-2xl rainbow-hover" style={{
                      textShadow: '2px 2px 0 hsl(var(--foreground) / 0.05)'
                    }}>{feature.title}</h3>
                    <p className="text-sm xl:text-base font-bold opacity-80">
                      {feature.description}
                    </p>
                  </CardContent>
                </div>
              );
            })}
          </div>
        </div>

        {/* Character Showcase - MEGA Ultra Cute - MOBILE OPTIMIZED */}
        <div
          ref={charactersSection.ref}
          className={`bouncy-card pop-in cartoon-card relative overflow-hidden mx-2 transition-all duration-1000 ${charactersSection.isVisible ? 'scroll-zoom-in' : 'opacity-0'}`}
          style={{
            background: 'linear-gradient(135deg, hsl(var(--card)) 0%, hsl(var(--muted)) 100%)',
            animationDelay: '0.6s',
            boxShadow: '0 25px 70px rgba(0,0,0,0.18), 0 0 50px rgba(255,165,0,0.25)',
          }}
        >
          {/* Mega Sparkle Background */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {[...Array(20)].map((_, i) => (
              <Star
                key={i}
                className="absolute text-yellow-400 sparkle-effect"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  width: `${15 + Math.random() * 20}px`,
                  height: `${15 + Math.random() * 20}px`,
                  animationDelay: `${i * 0.15}s`,
                }}
              />
            ))}
          </div>

          <CardContent className="p-5 xl:p-12 relative z-10">
            <h2 className="text-2xl xl:text-6xl font-black text-center mb-6 xl:mb-10 rainbow-hover px-2" style={{
              textShadow: '3px 3px 0 hsl(var(--foreground) / 0.1), 0 0 25px rgba(255,165,0,0.4)'
            }}>
              <span className="bg-gradient-to-r from-orange-500 via-pink-500 to-purple-500 bg-clip-text text-transparent">
                🎭✨ MEET YOUR CHESS PIECES ✨🎭
              </span>
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 xl:gap-8">
              {[
                { name: 'Naruto', role: 'King', emoji: '👑', color: 'from-orange-400 to-orange-600' },
                { name: 'Sasuke', role: 'Queen', emoji: '⚡', color: 'from-blue-400 to-blue-600' },
                { name: 'Kakashi', role: 'Bishop', emoji: '📖', color: 'from-purple-400 to-purple-600' },
                { name: 'Rock Lee', role: 'Knight', emoji: '🥋', color: 'from-green-400 to-green-600' },
                { name: 'Gaara', role: 'Rook', emoji: '🏰', color: 'from-red-400 to-red-600' },
                { name: 'Shadow Clone', role: 'Pawn', emoji: '🥷', color: 'from-slate-400 to-slate-600' },
              ].map((character, index) => {
                const colorAnimations = ['rainbow-badge', 'holographic', 'chakra-flow', 'gradient-rotate'];
                const animClass = colorAnimations[index % colorAnimations.length];
                return (
                <div
                  key={index}
                  className="text-center space-y-2 xl:space-y-4 p-4 xl:p-8 rounded-2xl xl:rounded-3xl bg-gradient-to-br from-card to-muted hover:scale-105 xl:hover:scale-110 transition-all duration-300 border-3 xl:border-4 border-primary/40 hover:border-primary shadow-2xl pop-in vibrant-pulse cartoon-card wiggle-hover relative overflow-hidden group"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  {/* Glow Effect on Hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-orange-400/0 to-pink-400/0 group-hover:from-orange-400/20 group-hover:to-pink-400/20 transition-all duration-500 rounded-2xl xl:rounded-3xl" />
                  
                  <div className="relative z-10">
                    <div className={`absolute inset-0 bg-gradient-to-br ${character.color} rounded-full blur-lg xl:blur-xl opacity-50 animate-pulse`} />
                    <div className={`mx-auto w-12 h-12 xl:w-20 xl:h-20 rounded-full ${animClass} shimmer-effect flex items-center justify-center shadow-2xl border-3 xl:border-4 border-white/70 neon-glow rainbow-hover relative`}>
                      <span className="text-2xl xl:text-4xl drop-shadow-[0_0_12px_rgba(255,255,255,1)]">{character.emoji}</span>
                    </div>
                    <div className="absolute inset-0 border-2 xl:border-3 border-dotted border-orange-300 rounded-full animate-spin-slow opacity-30" />
                  </div>
                  <div className="font-black text-base xl:text-lg relative z-10" style={{
                    textShadow: '2px 2px 4px rgba(0,0,0,0.3)'
                  }}>{character.name}</div>
                  <div className="text-sm xl:text-sm font-bold opacity-80 relative z-10">{character.role}</div>
                </div>
              )})}
            </div>
          </CardContent>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 xl:mt-16 px-2">
          <p className="text-xl xl:text-3xl font-black text-slate-700 dark:text-slate-300 rainbow-hover" style={{
            textShadow: '2px 2px 0 rgba(0,0,0,0.1)'
          }}>
            Ready to become a Chess Hokage? 🍥✨
          </p>
        </div>
      </div>
    </div>
  );
}
