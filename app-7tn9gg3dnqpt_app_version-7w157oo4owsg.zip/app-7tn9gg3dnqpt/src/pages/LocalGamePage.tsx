import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChessEngine } from '@/lib/chess/ChessEngine';
import ChessBoard from '@/components/chess/ChessBoard';
import { MoveHistory } from '@/components/chess/MoveHistory';
import { GameControls } from '@/components/chess/GameControls';
import { GameTimer } from '@/components/chess/GameTimer';
import { GameStatus } from '@/components/chess/GameStatus';
import GameEndModal from '@/components/chess/GameEndModal';
import GameActionsPanel from '@/components/chess/GameActionsPanel';
import { audioManager } from '@/lib/audio/AudioManager';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Position, TimeControl } from '@/types/types';

export default function LocalGamePage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [engine] = useState(() => new ChessEngine());
  const [gameStarted, setGameStarted] = useState(false);
  const [timeControl, setTimeControl] = useState<TimeControl>('blitz');
  const [showHints, setShowHints] = useState(true);
  const [whiteTime, setWhiteTime] = useState(300);
  const [blackTime, setBlackTime] = useState(300);
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [winner, setWinner] = useState<'white' | 'black' | 'draw' | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [selectedSquare, setSelectedSquare] = useState<Position | null>(null);
  const [validMoves, setValidMoves] = useState<Position[]>([]);
  const [moveHistory, setMoveHistory] = useState<any[]>([]);
  const [currentMoveIndex, setCurrentMoveIndex] = useState(-1);
  const [, forceUpdate] = useState({});
  const [gameResult, setGameResult] = useState<'checkmate' | 'draw' | 'resignation' | null>(null);
  const [showGameEndModal, setShowGameEndModal] = useState(false);

  useEffect(() => {
    audioManager.setSoundEnabled(soundEnabled);
    audioManager.setMusicEnabled(musicEnabled);
  }, [soundEnabled, musicEnabled]);

  const getTimeForControl = (control: TimeControl): number => {
    switch (control) {
      case 'bullet':
        return 60;
      case 'blitz':
        return 300;
      case 'rapid':
        return 600;
      case 'classical':
        return 1800;
      case 'unlimited':
        return 999999;
      default:
        return 300;
    }
  };

  const handleStartGame = () => {
    const time = getTimeForControl(timeControl);
    setWhiteTime(time);
    setBlackTime(time);
    setGameStarted(true);
    setIsTimerActive(true);
    setWinner(null);
    audioManager.startMusic();
    
    toast({
      title: 'Game Started',
      description: 'Local multiplayer game',
    });
  };

  const handleSquareClick = (pos: Position) => {
    const state = engine.getState();
    const piece = engine.getPiece(pos);
    
    // Allow both players to select their own pieces
    if (piece && piece.color === state.currentTurn) {
      setSelectedSquare(pos);
      setValidMoves(engine.getLegalMoves(pos));
    }
  };

  const handleMove = useCallback((from: Position, to: Position) => {
    const state = engine.getState();
    const piece = engine.getPiece(from);
    const captured = engine.getPiece(to);

    const success = engine.makeMove(from, to);
    
    if (success) {
      // Clear selection after successful move
      setSelectedSquare(null);
      setValidMoves([]);
      
      if (captured) {
        audioManager.playCapture();
      } else if (piece?.type === 'king' && Math.abs(to.col - from.col) === 2) {
        audioManager.playCastle();
      } else {
        audioManager.playMove();
      }

      const newState = engine.getState();
      setMoveHistory([...newState.moveHistory]);
      setCurrentMoveIndex(newState.moveHistory.length - 1);

      if (newState.isCheckmate) {
        audioManager.playCheckmate();
        setWinner(state.currentTurn);
        setGameResult('checkmate');
        setIsTimerActive(false);
        setShowGameEndModal(true);
        toast({
          title: 'Checkmate!',
          description: `${state.currentTurn === 'white' ? 'White' : 'Black'} wins!`,
        });
      } else if (newState.isCheck) {
        audioManager.playCheck();
      } else if (newState.isStalemate) {
        setWinner('draw');
        setGameResult('draw');
        setIsTimerActive(false);
        setShowGameEndModal(true);
        toast({
          title: 'Stalemate',
          description: 'The game is a draw',
        });
      }

      forceUpdate({});
    }
  }, [engine, toast]);

  const handleUndo = () => {
    if (engine.undoMove()) {
      const state = engine.getState();
      setMoveHistory([...state.moveHistory]);
      setCurrentMoveIndex(state.moveHistory.length - 1);
      forceUpdate({});
    }
  };

  const handleReset = () => {
    const newEngine = new ChessEngine();
    engine.setState(newEngine.getState());
    setWinner(null);
    setMoveHistory([]);
    setCurrentMoveIndex(-1);
    const time = getTimeForControl(timeControl);
    setWhiteTime(time);
    setBlackTime(time);
    setIsTimerActive(true);
    forceUpdate({});
    toast({
      title: 'Game Reset',
      description: 'Starting a new game',
    });
  };

  const handleResign = () => {
    const state = engine.getState();
    setWinner(state.currentTurn === 'white' ? 'black' : 'white');
    setGameResult('resignation');
    setIsTimerActive(false);
    setShowGameEndModal(true);
    toast({
      title: 'Game Over',
      description: `${state.currentTurn === 'white' ? 'White' : 'Black'} resigned`,
    });
  };

  const handleOfferDraw = () => {
    setWinner('draw');
    setGameResult('draw');
    setIsTimerActive(false);
    setShowGameEndModal(true);
    toast({
      title: 'Draw Declared',
      description: 'The game ended in a draw!',
    });
  };

  const handleNewGame = () => {
    const newEngine = new ChessEngine();
    engine.setState(newEngine.getState());
    setWinner(null);
    setGameResult(null);
    setShowGameEndModal(false);
    setMoveHistory([]);
    setCurrentMoveIndex(-1);
    const time = getTimeForControl(timeControl);
    setWhiteTime(time);
    setBlackTime(time);
    setIsTimerActive(true);
    forceUpdate({});
  };

  const handleSave = () => {
    const fen = engine.toFEN();
    localStorage.setItem('saved_game_local', fen);
    toast({
      title: 'Game Saved',
      description: 'Your game has been saved locally',
    });
  };

  const handleTimeOut = (color: 'white' | 'black') => {
    setWinner(color === 'white' ? 'black' : 'white');
    setIsTimerActive(false);
    toast({
      title: 'Time Out!',
      description: `${color === 'white' ? 'White' : 'Black'} ran out of time`,
    });
  };

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex items-center justify-center p-4 relative overflow-hidden">
        {/* Floating Naruto Elements */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute text-4xl animate-float opacity-30"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${i * 0.5}s`,
                animationDuration: `${4 + Math.random() * 3}s`,
              }}
            >
              {['🍥', '🥷', '⚡', '🔥', '💨', '🌀'][i]}
            </div>
          ))}
        </div>
        
        <Card className="w-full max-w-md relative z-10 chakra-pulse">
          <CardHeader>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              className="w-fit mb-2"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <CardTitle className="text-2xl">Game Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>Time Control</Label>
              <Select value={timeControl} onValueChange={(v) => setTimeControl(v as TimeControl)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bullet">Bullet (1 min)</SelectItem>
                  <SelectItem value="blitz">Blitz (5 min)</SelectItem>
                  <SelectItem value="rapid">Rapid (10 min)</SelectItem>
                  <SelectItem value="classical">Classical (30 min)</SelectItem>
                  <SelectItem value="unlimited">Unlimited</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <Label>Show Move Hints</Label>
              <Switch checked={showHints} onCheckedChange={setShowHints} />
            </div>

            <div className="flex items-center justify-between">
              <Label>Sound Effects</Label>
              <Switch checked={soundEnabled} onCheckedChange={setSoundEnabled} />
            </div>

            <div className="flex items-center justify-between">
              <Label>Background Music</Label>
              <Switch checked={musicEnabled} onCheckedChange={setMusicEnabled} />
            </div>

            <Button className="w-full" size="lg" onClick={handleStartGame}>
              Start Game
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const state = engine.getState();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 p-1 xl:p-4 relative overflow-hidden">
      {/* Floating Naruto Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute text-3xl xl:text-5xl animate-float opacity-20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.7}s`,
              animationDuration: `${5 + Math.random() * 4}s`,
            }}
          >
            {['🍥', '🥷', '⚡', '🔥', '💨', '🌀', '🍜', '⭐'][i]}
          </div>
        ))}
      </div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/')}
          className="mb-1 xl:mb-4 ml-1"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Menu
        </Button>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-1 xl:gap-6">
          <div className="xl:col-span-2 space-y-1 xl:space-y-4">
            <GameStatus gameState={state} gameMode="Local Multiplayer" winner={winner} />
            <div className="flex justify-center">
              <ChessBoard
                board={state.board}
                onMove={handleMove}
                validMoves={showHints ? validMoves : []}
                selectedSquare={selectedSquare}
                onSquareClick={handleSquareClick}
                isFlipped={false}
              />
            </div>
          </div>

          <div className="space-y-2 xl:space-y-4">
            {timeControl !== 'unlimited' && (
              <GameTimer
                whiteTime={whiteTime}
                blackTime={blackTime}
                currentTurn={state.currentTurn}
                isActive={isTimerActive}
                onTimeOut={handleTimeOut}
              />
            )}
            <GameActionsPanel
              onResign={handleResign}
              onOfferDraw={handleOfferDraw}
              onRequestTakeback={handleUndo}
              showTakeback={state.moveHistory.length > 0}
              isOnline={false}
            />
            <MoveHistory
              moves={moveHistory}
              currentMoveIndex={currentMoveIndex}
            />
          </div>
        </div>

        {/* Game End Modal */}
        <GameEndModal
          isOpen={showGameEndModal}
          result={gameResult}
          winner={winner}
          onNewGame={handleNewGame}
        />
      </div>
    </div>
  );
}
