import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChessEngine } from '@/lib/chess/ChessEngine';
import { ChessAI } from '@/lib/chess/ChessAI';
import ChessBoard from '@/components/chess/ChessBoard';
import { MoveHistory } from '@/components/chess/MoveHistory';
import { GameControls } from '@/components/chess/GameControls';
import { GameTimer } from '@/components/chess/GameTimer';
import { GameStatus } from '@/components/chess/GameStatus';
import GameEndModal from '@/components/chess/GameEndModal';
import GameActionsPanel from '@/components/chess/GameActionsPanel';
import { audioManager } from '@/lib/audio/AudioManager';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Position, Difficulty, TimeControl } from '@/types/types';

export default function AIGamePage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [engine] = useState(() => new ChessEngine());
  const [ai, setAi] = useState(() => new ChessAI(engine, 'medium'));
  const [gameStarted, setGameStarted] = useState(false);
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [timeControl, setTimeControl] = useState<TimeControl>('blitz');
  const [showHints, setShowHints] = useState(true);
  const [whiteTime, setWhiteTime] = useState(300);
  const [blackTime, setBlackTime] = useState(300);
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [winner, setWinner] = useState<'white' | 'black' | 'draw' | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [selectedSquare, setSelectedSquare] = useState<Position | null>(null);
  const [validMoves, setValidMoves] = useState<Position[]>([]);
  const [, forceUpdate] = useState({});
  const [gameResult, setGameResult] = useState<'checkmate' | 'draw' | 'resignation' | null>(null);
  const [showGameEndModal, setShowGameEndModal] = useState(false);

  useEffect(() => {
    audioManager.setSoundEnabled(soundEnabled);
    audioManager.setMusicEnabled(musicEnabled);
  }, [soundEnabled, musicEnabled]);

  const getTimeForControl = (control: TimeControl): number => {
    switch (control) {
      case 'bullet':
        return 60;
      case 'blitz':
        return 300;
      case 'rapid':
        return 600;
      case 'classical':
        return 1800;
      case 'unlimited':
        return 999999;
      default:
        return 300;
    }
  };

  const handleStartGame = () => {
    const time = getTimeForControl(timeControl);
    setWhiteTime(time);
    setBlackTime(time);
    setGameStarted(true);
    setIsTimerActive(true);
    setWinner(null);
    audioManager.startMusic();
    
    toast({
      title: 'Game Started',
      description: `Playing against AI (${difficulty} difficulty)`,
    });
  };

  const handleSquareClick = (pos: Position) => {
    const state = engine.getState();
    const piece = engine.getPiece(pos);
    
    // Only allow white pieces to be selected (player is white)
    if (piece && piece.color === 'white' && state.currentTurn === 'white') {
      setSelectedSquare(pos);
      setValidMoves(engine.getLegalMoves(pos));
    }
  };

  const handleMove = useCallback((from: Position, to: Position) => {
    const state = engine.getState();
    const piece = engine.getPiece(from);
    const captured = engine.getPiece(to);

    const success = engine.makeMove(from, to);
    
    if (success) {
      // Clear selection after successful move
      setSelectedSquare(null);
      setValidMoves([]);
      
      if (captured) {
        audioManager.playCapture();
      } else if (piece?.type === 'king' && Math.abs(to.col - from.col) === 2) {
        audioManager.playCastle();
      } else {
        audioManager.playMove();
      }

      const newState = engine.getState();
      if (newState.isCheckmate) {
        audioManager.playCheckmate();
        setWinner(state.currentTurn);
        setGameResult('checkmate');
        setIsTimerActive(false);
        setShowGameEndModal(true);
        toast({
          title: 'Checkmate!',
          description: `${state.currentTurn === 'white' ? 'White' : 'Black'} wins!`,
        });
      } else if (newState.isCheck) {
        audioManager.playCheck();
      } else if (newState.isStalemate) {
        setWinner('draw');
        setGameResult('draw');
        setIsTimerActive(false);
        setShowGameEndModal(true);
        toast({
          title: 'Stalemate',
          description: 'The game is a draw',
        });
      }

      forceUpdate({});

      if (newState.currentTurn === 'black' && !newState.isCheckmate && !newState.isStalemate) {
        setTimeout(() => {
          const aiMove = ai.getBestMove();
          if (aiMove) {
            handleMove(aiMove.from, aiMove.to);
          }
        }, 500);
      }
    }
  }, [engine, ai, toast]);

  const handleUndo = () => {
    engine.undoMove();
    engine.undoMove();
    forceUpdate({});
  };

  const handleReset = () => {
    const newEngine = new ChessEngine();
    engine.setState(newEngine.getState());
    setWinner(null);
    const time = getTimeForControl(timeControl);
    setWhiteTime(time);
    setBlackTime(time);
    setIsTimerActive(true);
    forceUpdate({});
    toast({
      title: 'Game Reset',
      description: 'Starting a new game',
    });
  };

  const handleResign = () => {
    setWinner('black');
    setGameResult('resignation');
    setIsTimerActive(false);
    setShowGameEndModal(true);
    toast({
      title: 'Game Over',
      description: 'You resigned. AI wins!',
    });
  };

  const handleOfferDraw = () => {
    setWinner('draw');
    setGameResult('draw');
    setIsTimerActive(false);
    setShowGameEndModal(true);
    toast({
      title: 'Draw Declared',
      description: 'The game ended in a draw!',
    });
  };

  const handleNewGame = () => {
    const newEngine = new ChessEngine();
    engine.setState(newEngine.getState());
    setWinner(null);
    setGameResult(null);
    setShowGameEndModal(false);
    const time = getTimeForControl(timeControl);
    setWhiteTime(time);
    setBlackTime(time);
    setIsTimerActive(true);
    forceUpdate({});
  };

  const handleSave = () => {
    const fen = engine.toFEN();
    localStorage.setItem('saved_game', fen);
    toast({
      title: 'Game Saved',
      description: 'Your game has been saved locally',
    });
  };

  const handleTimeOut = (color: 'white' | 'black') => {
    setWinner(color === 'white' ? 'black' : 'white');
    setIsTimerActive(false);
    toast({
      title: 'Time Out!',
      description: `${color === 'white' ? 'White' : 'Black'} ran out of time`,
    });
  };

  const handleDifficultyChange = (value: string) => {
    const newDifficulty = value as Difficulty;
    setDifficulty(newDifficulty);
    ai.setDifficulty(newDifficulty);
  };

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-orange-100 dark:from-slate-950 dark:via-orange-950/20 dark:to-slate-950 flex items-center justify-center p-4">
        <Card className="w-full max-w-md rounded-3xl overflow-hidden bg-white/95 dark:bg-slate-900/95 shadow-2xl border-4 border-orange-200 dark:border-orange-900/30 cartoon-card bounce-in">
          <CardHeader className="relative overflow-hidden px-4 py-6 xl:px-6 xl:py-8">
            {/* Smooth Flowing Background */}
            <div className="absolute inset-0 sunset-gradient opacity-20" />
            
            {/* Floating particles */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              {[...Array(10)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-2 h-2 rounded-full bg-orange-400 ember-float"
                  style={{
                    left: `${(i * 12) % 100}%`,
                    bottom: '0',
                    animationDelay: `${i * 0.4}s`,
                    animationDuration: `${3 + i * 0.3}s`
                  }}
                />
              ))}
            </div>

            <div className="relative z-10">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/')}
                className="w-fit mb-3 text-orange-600 dark:text-orange-400 hover:text-orange-700 dark:hover:text-orange-300 hover:bg-orange-100 dark:hover:bg-orange-950/50 cartoon-button"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex justify-center mb-4">
                <div className="ninja-gradient w-16 h-16 xl:w-20 xl:h-20 rounded-3xl flex items-center justify-center gentle-glow shadow-lg wiggle-hover">
                  <span className="text-3xl xl:text-4xl">🤖</span>
                </div>
              </div>
              <CardTitle className="text-2xl xl:text-4xl font-black text-center mb-2 xl:mb-3 px-2">
                <span className="bg-gradient-to-r from-orange-500 via-amber-500 to-orange-500 bg-clip-text text-transparent rainbow-hover">
                  AI CHALLENGE
                </span>
              </CardTitle>
              <p className="text-center text-orange-600 dark:text-orange-400 font-bold text-sm xl:text-base px-2">
                Face the ultimate AI opponent! 🎯
              </p>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 xl:space-y-6 relative z-10 px-4 py-6 xl:px-6 xl:py-8">
            <div className="space-y-2">
              <Label className="text-base xl:text-lg font-black text-orange-600 dark:text-orange-400 flex items-center gap-2">
                <span className="text-xl xl:text-2xl wiggle-hover inline-block">⚔️</span> Difficulty
              </Label>
              <Select value={difficulty} onValueChange={handleDifficultyChange}>
                <SelectTrigger className="text-base xl:text-lg font-bold border-3 sunset-border rounded-2xl h-12 xl:h-14 ninja-gradient text-white shadow-lg gentle-glow cartoon-button">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-3 border-orange-200 dark:border-orange-900/50">
                  <SelectItem value="easy" className="text-base xl:text-lg font-bold py-2 xl:py-3 cartoon-button">😊 Easy</SelectItem>
                  <SelectItem value="medium" className="text-base xl:text-lg font-bold py-2 xl:py-3 cartoon-button">😐 Medium</SelectItem>
                  <SelectItem value="hard" className="text-base xl:text-lg font-bold py-2 xl:py-3 cartoon-button">😈 Hard</SelectItem>
                  <SelectItem value="expert" className="text-base xl:text-lg font-bold py-2 xl:py-3 cartoon-button">💀 Expert</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-base xl:text-lg font-black text-orange-600 dark:text-orange-400 flex items-center gap-2">
                <span className="text-xl xl:text-2xl wiggle-hover inline-block">⏱️</span> Time Control
              </Label>
              <Select value={timeControl} onValueChange={(v) => setTimeControl(v as TimeControl)}>
                <SelectTrigger className="text-base xl:text-lg font-bold border-3 sunset-border rounded-2xl h-12 xl:h-14 twilight-gradient text-white shadow-lg gentle-glow cartoon-button">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-3 border-orange-200 dark:border-orange-900/50">
                  <SelectItem value="bullet" className="text-base xl:text-lg font-bold py-2 xl:py-3 cartoon-button">⚡ Bullet (1 min)</SelectItem>
                  <SelectItem value="blitz" className="text-base xl:text-lg font-bold py-2 xl:py-3 cartoon-button">🔥 Blitz (5 min)</SelectItem>
                  <SelectItem value="rapid" className="text-base xl:text-lg font-bold py-2 xl:py-3 cartoon-button">⏰ Rapid (10 min)</SelectItem>
                  <SelectItem value="classical" className="text-base xl:text-lg font-bold py-2 xl:py-3 cartoon-button">👑 Classical (30 min)</SelectItem>
                  <SelectItem value="unlimited" className="text-base xl:text-lg font-bold py-2 xl:py-3 cartoon-button">♾️ Unlimited</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between p-3 xl:p-4 rounded-2xl sunset-gradient glass-effect shadow-lg gentle-glow cartoon-card">
              <Label className="font-black text-sm xl:text-base text-white flex items-center gap-2 drop-shadow-lg">
                <span className="text-lg xl:text-xl wiggle-hover inline-block">💡</span> 
                <span className="hidden sm:inline">Show Move Hints</span>
                <span className="sm:hidden">Hints</span>
              </Label>
              <Switch checked={showHints} onCheckedChange={setShowHints} className="scale-110 xl:scale-125" />
            </div>

            <div className="flex items-center justify-between p-3 xl:p-4 rounded-2xl twilight-gradient glass-effect shadow-lg gentle-glow cartoon-card">
              <Label className="font-black text-sm xl:text-base text-white flex items-center gap-2 drop-shadow-lg">
                <span className="text-lg xl:text-xl wiggle-hover inline-block">🔊</span> 
                <span className="hidden sm:inline">Sound Effects</span>
                <span className="sm:hidden">Sound</span>
              </Label>
              <Switch checked={soundEnabled} onCheckedChange={setSoundEnabled} className="scale-110 xl:scale-125" />
            </div>

            <div className="flex items-center justify-between p-3 xl:p-4 rounded-2xl dawn-gradient glass-effect shadow-lg gentle-glow cartoon-card">
              <Label className="font-black text-sm xl:text-base text-white flex items-center gap-2 drop-shadow-lg">
                <span className="text-lg xl:text-xl wiggle-hover inline-block">🎵</span> 
                <span className="hidden sm:inline">Background Music</span>
                <span className="sm:hidden">Music</span>
              </Label>
              <Switch checked={musicEnabled} onCheckedChange={setMusicEnabled} className="scale-110 xl:scale-125" />
            </div>

            <Button 
              className="w-full text-lg xl:text-2xl py-6 xl:py-8 rounded-2xl font-black ninja-gradient text-white shadow-2xl cartoon-button gentle-glow border-0" 
              size="lg" 
              onClick={handleStartGame}
            >
              <span className="hidden sm:inline">⚔️ START BATTLE ⚔️</span>
              <span className="sm:hidden">⚔️ START ⚔️</span>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const state = engine.getState();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 p-1 xl:p-4 relative overflow-hidden">
      {/* Floating Naruto Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute text-3xl xl:text-5xl animate-float opacity-20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.7}s`,
              animationDuration: `${5 + Math.random() * 4}s`,
            }}
          >
            {['🍥', '🥷', '⚡', '🔥', '💨', '🌀', '🍜', '⭐'][i]}
          </div>
        ))}
      </div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/')}
          className="mb-1 xl:mb-4 ml-1"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Menu
        </Button>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-1 xl:gap-6">
          <div className="xl:col-span-2 space-y-1 xl:space-y-4">
            <GameStatus gameState={state} gameMode={`AI (${difficulty})`} winner={winner} />
            <div className="flex justify-center">
              <ChessBoard
                board={state.board}
                onMove={handleMove}
                validMoves={showHints ? validMoves : []}
                selectedSquare={selectedSquare}
                onSquareClick={handleSquareClick}
                isFlipped={false}
              />
            </div>
          </div>

          <div className="space-y-2 xl:space-y-4">
            {timeControl !== 'unlimited' && (
              <GameTimer
                whiteTime={whiteTime}
                blackTime={blackTime}
                currentTurn={state.currentTurn}
                isActive={isTimerActive}
                onTimeOut={handleTimeOut}
              />
            )}
            <GameActionsPanel
              onResign={handleResign}
              onOfferDraw={handleOfferDraw}
              onRequestTakeback={handleUndo}
              showTakeback={state.moveHistory.length > 0}
              isOnline={false}
            />
            <MoveHistory moves={state.moveHistory} />
          </div>
        </div>

        {/* Game End Modal */}
        <GameEndModal
          isOpen={showGameEndModal}
          result={gameResult}
          winner={winner}
          onNewGame={handleNewGame}
        />
      </div>
    </div>
  );
}
