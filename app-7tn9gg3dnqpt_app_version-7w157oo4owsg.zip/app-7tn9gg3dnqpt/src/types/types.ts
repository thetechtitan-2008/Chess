export interface OnlineGame {
  id: string;
  white_player_id: string | null;
  black_player_id: string | null;
  current_fen: string;
  game_mode: string;
  time_control: number;
  white_time_remaining: number;
  black_time_remaining: number;
  current_turn: 'white' | 'black';
  status: 'waiting' | 'active' | 'completed' | 'abandoned';
  winner: 'white' | 'black' | 'draw' | null;
  result_reason: 'checkmate' | 'timeout' | 'resignation' | 'draw_agreement' | 'stalemate' | null;
  game_code?: string | null;
  created_at: string;
  updated_at: string;
}

export interface GameMove {
  id: string;
  game_id: string;
  move_number: number;
  move_notation: string;
  from_square: string;
  to_square: string;
  piece: string;
  captured_piece: string | null;
  is_check: boolean;
  is_checkmate: boolean;
  fen_after_move: string;
  timestamp: string;
}

export interface SavedGame {
  id: string;
  player_id: string;
  game_name: string;
  game_mode: string;
  current_fen: string;
  move_history: MoveHistoryEntry[];
  created_at: string;
  updated_at: string;
}

export interface MoveHistoryEntry {
  from: string;
  to: string;
  piece: string;
  captured?: string;
  notation: string;
  fen: string;
}

export type PieceType = 'king' | 'queen' | 'rook' | 'bishop' | 'knight' | 'pawn';
export type PieceColor = 'white' | 'black';

export interface ChessPiece {
  type: PieceType;
  color: PieceColor;
  hasMoved?: boolean;
}

export interface Position {
  row: number;
  col: number;
}

export interface Move {
  from: Position;
  to: Position;
  piece: ChessPiece;
  captured?: ChessPiece;
  isEnPassant?: boolean;
  isCastling?: boolean;
  promotion?: PieceType;
}

export interface GameState {
  board: (ChessPiece | null)[][];
  currentTurn: PieceColor;
  moveHistory: Move[];
  isCheck: boolean;
  isCheckmate: boolean;
  isStalemate: boolean;
  enPassantTarget: Position | null;
  castlingRights: {
    whiteKingSide: boolean;
    whiteQueenSide: boolean;
    blackKingSide: boolean;
    blackQueenSide: boolean;
  };
}

export type GameMode = 'ai' | 'local' | 'online';
export type Difficulty = 'easy' | 'medium' | 'hard' | 'expert';
export type TimeControl = 'bullet' | 'blitz' | 'rapid' | 'classical' | 'unlimited';

export interface GameSettings {
  mode: GameMode;
  difficulty?: Difficulty;
  timeControl: TimeControl;
  timeInSeconds: number;
  soundEnabled: boolean;
  musicEnabled: boolean;
  showHints: boolean;
}
