import React from "react";
import { Sparkles, Zap } from "lucide-react";

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative overflow-hidden bg-gradient-to-br from-orange-500/10 via-blue-500/10 to-purple-500/10 dark:from-orange-900/20 dark:via-blue-900/20 dark:to-purple-900/20 border-t-4 border-orange-400 dark:border-orange-600">
      {/* Naruto-themed background effects */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-gradient-to-br from-orange-400/20 to-transparent rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-gradient-to-br from-blue-400/20 to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        {/* Main content */}
        <div className="text-center space-y-6">
          {/* Naruto-themed title */}
          <div className="flex items-center justify-center gap-3 mb-6">
            <span className="text-4xl animate-bounce">🍥</span>
            <h3 className="text-3xl font-black bg-gradient-to-r from-orange-500 via-yellow-500 to-orange-600 bg-clip-text text-transparent">
              Naruto Chess Game
            </h3>
            <span className="text-4xl animate-bounce" style={{ animationDelay: '0.2s' }}>⚡</span>
          </div>

          {/* Description */}
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Experience the ultimate fusion of strategy and ninja action! Play chess with your favorite Naruto characters.
          </p>

          {/* Decorative divider */}
          <div className="flex items-center justify-center gap-4 py-6">
            <div className="h-px w-24 bg-gradient-to-r from-transparent via-orange-400 to-transparent" />
            <Sparkles className="w-6 h-6 text-orange-500 animate-pulse" />
            <div className="h-px w-24 bg-gradient-to-r from-transparent via-blue-400 to-transparent" />
          </div>

          {/* Creator credit - Naruto style */}
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-gradient-to-r from-orange-400 via-yellow-400 to-orange-500 blur-xl opacity-30 animate-pulse" />
            <div className="relative bg-gradient-to-br from-card to-muted border-2 border-orange-400 dark:border-orange-600 rounded-2xl px-8 py-6 shadow-2xl">
              <div className="flex items-center justify-center gap-3 mb-3">
                <Zap className="w-6 h-6 text-orange-500 animate-pulse" />
                <span className="text-sm font-bold text-muted-foreground uppercase tracking-wider">
                  Created by
                </span>
                <Zap className="w-6 h-6 text-blue-500 animate-pulse" style={{ animationDelay: '0.5s' }} />
              </div>
              <h2 className="text-4xl font-black bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 bg-clip-text text-transparent mb-2">
                Abhiram R Ajay
              </h2>
              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <span className="text-2xl">🥷</span>
                <span className="font-semibold">Ninja Developer</span>
                <span className="text-2xl">🔥</span>
              </div>
            </div>
          </div>

          {/* Floating Naruto elements */}
          <div className="flex items-center justify-center gap-4 text-3xl py-4">
            <span className="animate-bounce">🍜</span>
            <span className="animate-bounce" style={{ animationDelay: '0.1s' }}>⭐</span>
            <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>🌀</span>
            <span className="animate-bounce" style={{ animationDelay: '0.3s' }}>💨</span>
            <span className="animate-bounce" style={{ animationDelay: '0.4s' }}>🔥</span>
          </div>

          {/* Copyright */}
          <div className="pt-6 border-t border-border/50">
            <p className="text-sm text-muted-foreground">
              {currentYear} Naruto Chess Game
            </p>
            <p className="text-xs text-muted-foreground/70 mt-2">
              Believe it! 🍥 Dattebayo!
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
