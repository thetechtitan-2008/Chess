import { useEffect, useState } from 'react';

interface IntroSplashProps {
  onComplete: () => void;
}

export default function IntroSplash({ onComplete }: IntroSplashProps) {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    // PERFECT MASTERPIECE ANIMATION - 8 seconds of pure awesomeness!
    // Smoother timing with longer text visibility
    const timers = [
      setTimeout(() => setStage(1), 300),    // Konoha symbol appears (smoother)
      setTimeout(() => setStage(2), 1200),   // Naruto enters with chakra burst
      setTimeout(() => setStage(3), 2400),   // Shadow clones multiply
      setTimeout(() => setStage(4), 3800),   // Rasengan formation
      setTimeout(() => setStage(5), 5000),   // Title reveal (stays longer!)
      setTimeout(() => setStage(6), 6500),   // Final epic pose (stays longer!)
      setTimeout(() => onComplete(), 8000),  // Complete after 8 seconds (more time to read!)
    ];

    return () => timers.forEach(clearTimeout);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[9999] w-screen h-screen overflow-hidden">
      {/* STAGE 0-1: Epic Background - Animated Gradient (SMOOTHER) */}
      <div 
        className={`absolute inset-0 transition-all duration-2000 ${
          stage >= 1 ? 'opacity-100' : 'opacity-0'
        }`}
        style={{
          background: 'linear-gradient(135deg, #ff6b00 0%, #ff8c00 20%, #1e40af 50%, #3b82f6 80%, #ff6b00 100%)',
          backgroundSize: '400% 400%',
          animation: 'gradientShift 10s ease infinite',
        }}
      />

      {/* TWINKLING STARS BACKGROUND - LOTS OF STARS! */}
      <div className="absolute inset-0">
        {[...Array(60)].map((_, i) => (
          <div
            key={`star-${i}`}
            className={`absolute rounded-full bg-white transition-all duration-1000 ${
              stage >= 1 ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              width: `${Math.random() * 3 + 1}px`,
              height: `${Math.random() * 3 + 1}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `twinkle ${2 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
              boxShadow: '0 0 10px rgba(255, 255, 255, 0.8), 0 0 20px rgba(255, 255, 255, 0.4)',
            }}
          />
        ))}
      </div>

      {/* SHOOTING STARS - EPIC EFFECT! */}
      <div className="absolute inset-0">
        {[...Array(8)].map((_, i) => (
          <div
            key={`shooting-${i}`}
            className={`absolute transition-all duration-1000 ${
              stage >= 2 ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              width: '2px',
              height: '100px',
              background: 'linear-gradient(to bottom, rgba(255,255,255,0), rgba(255,255,255,0.8), rgba(255,255,255,0))',
              left: `${Math.random() * 100}%`,
              top: '-100px',
              animation: `shootingStar ${3 + Math.random() * 2}s linear infinite`,
              animationDelay: `${i * 0.8}s`,
              transform: 'rotate(45deg)',
              filter: 'blur(1px)',
            }}
          />
        ))}
      </div>

      {/* Animated Particles - Epic Chakra Flow (MORE PARTICLES!) */}
      <div className="absolute inset-0">
        {[...Array(50)].map((_, i) => (
          <div
            key={`particle-${i}`}
            className={`absolute rounded-full transition-all duration-1500 ${
              stage >= 2 ? 'opacity-100' : 'opacity-0'
            } ${i % 3 === 0 ? 'bg-orange-400' : i % 3 === 1 ? 'bg-blue-400' : 'bg-yellow-300'}`}
            style={{
              width: `${Math.random() * 10 + 4}px`,
              height: `${Math.random() * 10 + 4}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${4 + Math.random() * 5}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
              filter: 'blur(1px)',
              boxShadow: '0 0 20px currentColor',
            }}
          />
        ))}
      </div>

      {/* STAGE 1: Konoha Symbol - Epic Entrance (SMOOTHER) */}
      <div 
        className={`absolute inset-0 flex items-center justify-center transition-all duration-2000 ${
          stage >= 1 && stage < 4 ? 'opacity-30 scale-100' : stage >= 4 ? 'opacity-10 scale-150' : 'opacity-0 scale-50'
        }`}
      >
        <div className="relative">
          <img
            src="https://miaoda-site-img.s3cdn.medo.dev/images/4029add7-e1b0-4416-89c9-a8a68036b138.jpg"
            alt="Konoha"
            className="w-[80vmin] h-[80vmin] object-contain"
            style={{
              animation: 'spin 25s linear infinite',
              filter: 'drop-shadow(0 0 50px rgba(255, 107, 0, 0.8))',
            }}
            loading="eager"
          />
        </div>
      </div>

      {/* STAGE 2-3: Rasengan Rings - Epic Spinning (SMOOTHER) */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <div
            key={`ring-${i}`}
            className={`absolute rounded-full border-4 transition-all duration-1500 ${
              stage >= 2 ? 'opacity-60' : 'opacity-0'
            }`}
            style={{
              width: `${30 + i * 15}vmin`,
              height: `${30 + i * 15}vmin`,
              borderColor: i % 2 === 0 ? 'rgba(59, 130, 246, 0.7)' : 'rgba(255, 107, 0, 0.7)',
              animation: `rasenganSpin ${2.5 + i * 0.6}s ease-in-out infinite ${i % 2 === 0 ? 'normal' : 'reverse'}`,
              animationDelay: `${i * 0.2}s`,
              filter: 'blur(2px)',
              boxShadow: `0 0 40px ${i % 2 === 0 ? 'rgba(59, 130, 246, 0.9)' : 'rgba(255, 107, 0, 0.9)'}`,
            }}
          />
        ))}
      </div>

      {/* STAGE 2: Naruto Character - EPIC CENTER PIECE (SMOOTHER) */}
      <div 
        className={`absolute inset-0 flex items-center justify-center transition-all duration-2000 ${
          stage >= 2 ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
        }`}
      >
        <div className="relative">
          {/* Epic Glow Effects (STRONGER) */}
          <div 
            className="absolute inset-0 rounded-full"
            style={{
              background: 'radial-gradient(circle, rgba(255,107,0,0.5) 0%, rgba(59,130,246,0.5) 50%, transparent 70%)',
              filter: 'blur(80px)',
              animation: 'pulse 2.5s ease-in-out infinite',
              transform: 'scale(2.5)',
            }}
          />
          
          {/* SPARKLE EFFECTS AROUND NARUTO */}
          {[...Array(12)].map((_, i) => (
            <div
              key={`sparkle-${i}`}
              className={`absolute rounded-full bg-white transition-all duration-1000 ${
                stage >= 2 ? 'opacity-100' : 'opacity-0'
              }`}
              style={{
                width: '4px',
                height: '4px',
                left: `${50 + Math.cos((i * Math.PI * 2) / 12) * 60}%`,
                top: `${50 + Math.sin((i * Math.PI * 2) / 12) * 60}%`,
                animation: `sparkle ${1.5 + i * 0.1}s ease-in-out infinite`,
                animationDelay: `${i * 0.1}s`,
                boxShadow: '0 0 15px rgba(255, 255, 255, 1), 0 0 30px rgba(255, 255, 255, 0.6)',
              }}
            />
          ))}
          
          {/* Naruto Image (SMOOTHER GROWTH) */}
          <img
            src="https://miaoda-site-img.s3cdn.medo.dev/images/9eb7e1e5-97b3-48db-80d0-8f401b8fb9f3.jpg"
            alt="Naruto"
            className={`relative rounded-full object-cover border-8 border-white transition-all duration-2000 ${
              stage >= 3 ? 'w-[50vmin] h-[50vmin]' : 'w-[40vmin] h-[40vmin]'
            }`}
            style={{
              boxShadow: '0 0 100px rgba(255, 107, 0, 1), 0 0 150px rgba(59, 130, 246, 0.8), inset 0 0 50px rgba(255, 255, 255, 0.3)',
              animation: 'chakraPulse 2.5s ease-in-out infinite',
            }}
            loading="eager"
          />

          {/* Chakra Ring Effects (MORE RINGS!) */}
          {[...Array(5)].map((_, i) => (
            <div
              key={`chakra-${i}`}
              className={`absolute inset-0 rounded-full border-4 transition-all duration-1500 ${
                stage >= 2 ? 'opacity-100' : 'opacity-0'
              }`}
              style={{
                borderColor: i % 2 === 0 ? 'rgba(255, 107, 0, 0.7)' : 'rgba(59, 130, 246, 0.7)',
                animation: `${i % 2 === 0 ? 'ping' : 'pulse'} ${1.8 + i * 0.3}s cubic-bezier(0, 0, 0.2, 1) infinite`,
                animationDelay: `${i * 0.2}s`,
                transform: `scale(${1 + i * 0.2})`,
              }}
            />
          ))}
        </div>
      </div>

      {/* STAGE 3: Shadow Clone Effect (SMOOTHER) */}
      {stage >= 3 && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(8)].map((_, i) => (
            <div
              key={`clone-${i}`}
              className="absolute transition-all duration-1500"
              style={{
                left: `${50 + Math.cos((i * Math.PI * 2) / 8) * 35}%`,
                top: `${50 + Math.sin((i * Math.PI * 2) / 8) * 35}%`,
                transform: 'translate(-50%, -50%)',
                opacity: stage >= 3 ? 0.4 : 0,
                animation: `float ${2.5 + i * 0.3}s ease-in-out infinite`,
                animationDelay: `${i * 0.15}s`,
              }}
            >
              <img
                src="https://miaoda-site-img.s3cdn.medo.dev/images/9eb7e1e5-97b3-48db-80d0-8f401b8fb9f3.jpg"
                alt="Clone"
                className="w-[15vmin] h-[15vmin] rounded-full object-cover border-4 border-orange-400"
                style={{
                  filter: 'blur(2px) brightness(0.8)',
                  boxShadow: '0 0 40px rgba(255, 107, 0, 0.8)',
                }}
              />
            </div>
          ))}
        </div>
      )}

      {/* STAGE 4: Rasengan Formation - Epic Center (SMOOTHER) */}
      {stage >= 4 && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div 
            className="relative transition-all duration-1500"
            style={{
              opacity: stage >= 4 ? 1 : 0,
              transform: stage >= 4 ? 'scale(1)' : 'scale(0)',
            }}
          >
            {[...Array(4)].map((_, i) => (
              <div
                key={`rasengan-${i}`}
                className="absolute rounded-full"
                style={{
                  width: `${20 + i * 12}vmin`,
                  height: `${20 + i * 12}vmin`,
                  left: '50%',
                  top: '50%',
                  transform: 'translate(-50%, -50%)',
                  background: `radial-gradient(circle, ${
                    i === 0 ? 'rgba(255,255,255,0.9)' : i === 1 ? 'rgba(59,130,246,0.7)' : i === 2 ? 'rgba(255,107,0,0.5)' : 'rgba(255,255,0,0.3)'
                  }, transparent)`,
                  animation: `rasenganSpin ${1.2 + i * 0.6}s ease-in-out infinite ${i % 2 === 0 ? 'normal' : 'reverse'}`,
                  filter: 'blur(12px)',
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* STAGE 5: Title Reveal - EPIC TEXT (STAYS LONGER!) */}
      <div 
        className={`absolute inset-0 flex flex-col items-center justify-center transition-all duration-2000 ${
          stage >= 5 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20'
        }`}
        style={{ zIndex: 10 }}
      >
        <h1 
          className="font-black text-white mb-4 text-center px-4"
          style={{
            fontSize: 'clamp(3rem, 12vmin, 10rem)',
            textShadow: '8px 8px 0 rgba(0,0,0,0.5), 0 0 50px rgba(255,107,0,1), 0 0 100px rgba(59,130,246,1), 0 0 150px rgba(255,107,0,0.8)',
            animation: 'pulse 2.5s ease-in-out infinite',
            letterSpacing: '0.15em',
            lineHeight: '1.2',
          }}
        >
          NARUTO<br />CHESS
        </h1>
        
        {stage >= 6 && (
          <p 
            className="font-bold text-white text-center px-4"
            style={{
              fontSize: 'clamp(1.5rem, 5vmin, 4rem)',
              textShadow: '4px 4px 0 rgba(0,0,0,0.4), 0 0 30px rgba(255,107,0,1), 0 0 60px rgba(255,107,0,0.6)',
              animation: 'bounce 1.2s ease-in-out infinite',
            }}
          >
            Believe It! 🍥
          </p>
        )}
      </div>

      {/* STAGE 6: Final Loading Indicator (SMOOTHER) */}
      {stage >= 6 && (
        <div 
          className="absolute bottom-[10vh] left-1/2 transform -translate-x-1/2 transition-all duration-1500"
          style={{
            opacity: stage >= 6 ? 1 : 0,
          }}
        >
          <div className="flex gap-3">
            {[...Array(3)].map((_, i) => (
              <div
                key={`loader-${i}`}
                className="rounded-full bg-white"
                style={{
                  width: 'clamp(14px, 2.5vmin, 24px)',
                  height: 'clamp(14px, 2.5vmin, 24px)',
                  animation: 'bounce 1.2s ease-in-out infinite',
                  animationDelay: `${i * 0.2}s`,
                  boxShadow: '0 0 25px rgba(255, 255, 255, 1), 0 0 50px rgba(255, 255, 255, 0.6)',
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Epic Light Rays (MORE RAYS!) */}
      {stage >= 4 && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {[...Array(16)].map((_, i) => (
            <div
              key={`ray-${i}`}
              className="absolute h-full"
              style={{
                width: '3px',
                left: `${(i * 100) / 16}%`,
                background: 'linear-gradient(to bottom, transparent, rgba(255,255,255,0.4), transparent)',
                animation: `lightRay ${3.5 + i * 0.4}s ease-in-out infinite`,
                animationDelay: `${i * 0.25}s`,
                transformOrigin: 'top center',
                transform: `rotate(${i * 22.5}deg)`,
                filter: 'blur(1px)',
              }}
            />
          ))}
        </div>
      )}

      {/* STAR BURST EFFECT - FINAL TOUCH! */}
      {stage >= 5 && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          {[...Array(20)].map((_, i) => (
            <div
              key={`burst-${i}`}
              className="absolute"
              style={{
                width: '4px',
                height: '40px',
                background: 'linear-gradient(to bottom, rgba(255,255,255,1), transparent)',
                transform: `rotate(${i * 18}deg) translateY(-30vmin)`,
                animation: `starBurst 2s ease-out infinite`,
                animationDelay: `${i * 0.1}s`,
                filter: 'blur(1px)',
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
