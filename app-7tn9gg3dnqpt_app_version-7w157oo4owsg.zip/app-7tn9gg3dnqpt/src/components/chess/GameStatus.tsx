import { Card, CardContent } from '@/components/ui/card';
import { AlertCircle, Trophy, Swords } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { GameState } from '@/types/types';

interface GameStatusProps {
  gameState: GameState;
  gameMode: string;
  winner?: 'white' | 'black' | 'draw' | null;
}

export function GameStatus({ gameState, gameMode, winner }: GameStatusProps) {
  const getStatusMessage = () => {
    if (winner) {
      if (winner === 'draw') {
        return { text: 'Game Draw!', icon: Swords, color: 'text-muted-foreground' };
      }
      return {
        text: `${winner === 'white' ? 'White' : 'Black'} Wins!`,
        icon: Trophy,
        color: 'text-accent',
      };
    }

    if (gameState.isCheckmate) {
      const winner = gameState.currentTurn === 'white' ? 'Black' : 'White';
      return { text: `Checkmate! ${winner} Wins!`, icon: Trophy, color: 'text-accent' };
    }

    if (gameState.isStalemate) {
      return { text: 'Stalemate! Game Draw', icon: Swords, color: 'text-muted-foreground' };
    }

    if (gameState.isCheck) {
      return { text: 'Check!', icon: AlertCircle, color: 'text-destructive' };
    }

    return {
      text: `${gameState.currentTurn === 'white' ? 'White' : 'Black'} to move`,
      icon: Swords,
      color: 'text-foreground',
    };
  };

  const status = getStatusMessage();
  const Icon = status.icon;

  return (
    <Card className="border-2 border-primary">
      <CardContent className="p-3 xl:p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 xl:gap-3">
            <Icon className={cn('w-5 h-5 xl:w-6 xl:h-6', status.color)} />
            <div>
              <p className={cn('text-base xl:text-xl font-bold', status.color)}>
                {status.text}
              </p>
              <p className="text-xs xl:text-sm text-muted-foreground capitalize">
                {gameMode} Mode
              </p>
            </div>
          </div>
          {gameState.isCheck && !gameState.isCheckmate && (
            <div className="animate-pulse">
              <AlertCircle className="w-6 h-6 xl:w-8 xl:h-8 text-destructive" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
