import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Trophy, Handshake, RotateCcw, Home } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface GameEndModalProps {
  isOpen: boolean;
  result: 'checkmate' | 'draw' | 'resignation' | null;
  winner: 'white' | 'black' | 'draw' | null;
  onNewGame: () => void;
}

export default function GameEndModal({ isOpen, result, winner, onNewGame }: GameEndModalProps) {
  const navigate = useNavigate();

  const getTitle = () => {
    if (result === 'checkmate') {
      return winner === 'white' ? '🎉 White Wins!' : '🎉 Black Wins!';
    }
    if (result === 'draw') {
      return '🤝 Draw!';
    }
    if (result === 'resignation') {
      return winner === 'white' ? '🏳️ Black Resigned' : '🏳️ White Resigned';
    }
    return 'Game Over';
  };

  const getMessage = () => {
    if (result === 'checkmate') {
      return `Checkmate! ${winner === 'white' ? 'White' : 'Black'} has won the game!`;
    }
    if (result === 'draw') {
      return 'The game ended in a draw. Well played!';
    }
    if (result === 'resignation') {
      return `${winner === 'white' ? 'Black' : 'White'} has resigned. ${winner === 'white' ? 'White' : 'Black'} wins!`;
    }
    return '';
  };

  const getIcon = () => {
    if (result === 'checkmate' || result === 'resignation') {
      return <Trophy className="w-24 h-24 text-orange-500 victory-bounce" />;
    }
    return <Handshake className="w-24 h-24 text-blue-500 victory-bounce" />;
  };

  return (
    <Dialog open={isOpen}>
      <DialogContent className="sm:max-w-md elegant-card border-4 border-white/50">
        <DialogHeader>
          <DialogTitle className="text-center text-3xl font-black bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
            {getTitle()}
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col items-center gap-6 py-6">
          {/* Animated Icon */}
          <div className="relative">
            {/* Confetti effect */}
            {(result === 'checkmate' || result === 'resignation') && (
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(20)].map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-2 h-2 rounded-full confetti-fall"
                    style={{
                      left: `${Math.random() * 100}%`,
                      backgroundColor: ['#ff6b6b', '#4ecdc4', '#45b7d1', '#f9ca24', '#6c5ce7'][i % 5],
                      animationDelay: `${Math.random() * 2}s`,
                    }}
                  />
                ))}
              </div>
            )}
            {getIcon()}
          </div>

          {/* Message */}
          <p className="text-center text-lg font-semibold text-slate-700 dark:text-slate-300 px-4">
            {getMessage()}
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 w-full">
            <Button
              type="button"
              onClick={onNewGame}
              className="flex-1 bg-gradient-to-r from-green-500 to-teal-600 text-white font-bold py-6 rounded-2xl shadow-lg hover:scale-105 transition-transform button-press"
              size="lg"
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              New Game
            </Button>
            <Button
              type="button"
              onClick={() => navigate('/')}
              className="flex-1 bg-gradient-to-r from-purple-500 to-purple-700 text-white font-bold py-6 rounded-2xl shadow-lg hover:scale-105 transition-transform button-press"
              size="lg"
            >
              <Home className="w-5 h-5 mr-2" />
              Home
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
