import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Flag, Handshake, Undo2, AlertCircle } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface GameActionsPanelProps {
  onResign: () => void;
  onOfferDraw: () => void;
  onRequestTakeback?: () => void;
  showTakeback?: boolean;
  isOnline?: boolean;
  pendingDrawOffer?: boolean;
  pendingTakebackRequest?: boolean;
  onAcceptDraw?: () => void;
  onDeclineDraw?: () => void;
  onAcceptTakeback?: () => void;
  onDeclineTakeback?: () => void;
}

export default function GameActionsPanel({
  onResign,
  onOfferDraw,
  onRequestTakeback,
  showTakeback = true,
  isOnline = false,
  pendingDrawOffer = false,
  pendingTakebackRequest = false,
  onAcceptDraw,
  onDeclineDraw,
  onAcceptTakeback,
  onDeclineTakeback,
}: GameActionsPanelProps) {
  return (
    <Card className="border-4 border-white/50 rounded-3xl overflow-hidden elegant-card">
      <CardContent className="p-3 xl:p-6">
        <h3 className="text-base xl:text-xl font-black text-center mb-3 xl:mb-4 bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
          Game Actions
        </h3>

        {/* Pending Draw Offer */}
        {pendingDrawOffer && onAcceptDraw && onDeclineDraw && (
          <Card className="mb-3 xl:mb-4 border-2 border-blue-400 bg-blue-50 dark:bg-blue-950">
            <CardContent className="p-3 xl:p-4">
              <div className="flex items-center gap-2 mb-2 xl:mb-3">
                <AlertCircle className="w-4 h-4 xl:w-5 xl:h-5 text-blue-600" />
                <p className="text-sm xl:text-base font-bold text-blue-800 dark:text-blue-200">Draw Offer Received</p>
              </div>
              <div className="flex gap-2">
                <Button
                  type="button"
                  onClick={onAcceptDraw}
                  className="flex-1 bg-gradient-to-r from-green-500 to-teal-600 text-white font-bold rounded-xl button-press text-xs xl:text-sm"
                  size="sm"
                >
                  Accept
                </Button>
                <Button
                  type="button"
                  onClick={onDeclineDraw}
                  className="flex-1 bg-gradient-to-r from-red-500 to-red-600 text-white font-bold rounded-xl button-press text-xs xl:text-sm"
                  size="sm"
                >
                  Decline
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Pending Takeback Request */}
        {pendingTakebackRequest && onAcceptTakeback && onDeclineTakeback && (
          <Card className="mb-3 xl:mb-4 border-2 border-purple-400 bg-purple-50 dark:bg-purple-950">
            <CardContent className="p-3 xl:p-4">
              <div className="flex items-center gap-2 mb-2 xl:mb-3">
                <AlertCircle className="w-4 h-4 xl:w-5 xl:h-5 text-purple-600" />
                <p className="text-sm xl:text-base font-bold text-purple-800 dark:text-purple-200">Takeback Request</p>
              </div>
              <div className="flex gap-2">
                <Button
                  type="button"
                  onClick={onAcceptTakeback}
                  className="flex-1 bg-gradient-to-r from-green-500 to-teal-600 text-white font-bold rounded-xl button-press text-xs xl:text-sm"
                  size="sm"
                >
                  Accept
                </Button>
                <Button
                  type="button"
                  onClick={onDeclineTakeback}
                  className="flex-1 bg-gradient-to-r from-red-500 to-red-600 text-white font-bold rounded-xl button-press text-xs xl:text-sm"
                  size="sm"
                >
                  Decline
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex flex-col gap-2 xl:gap-3">
          {/* Resign Button */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                className="w-full bg-gradient-to-r from-red-500 to-red-600 text-white font-bold py-4 xl:py-6 rounded-xl xl:rounded-2xl shadow-lg hover:scale-105 transition-transform text-sm xl:text-base cursor-pointer"
                size="lg"
              >
                <Flag className="w-4 h-4 xl:w-5 xl:h-5 mr-2" />
                Resign
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="elegant-card border-4 border-white/50">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-xl xl:text-2xl font-black bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">
                  Resign Game?
                </AlertDialogTitle>
                <AlertDialogDescription className="text-sm xl:text-base font-semibold">
                  Are you sure you want to resign? This will end the game and you will lose.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="rounded-xl font-bold text-xs xl:text-sm cursor-pointer">
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={onResign}
                  className="bg-gradient-to-r from-red-500 to-red-600 text-white font-bold rounded-xl text-xs xl:text-sm cursor-pointer"
                >
                  Yes, Resign
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {/* Offer Draw Button */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white font-bold py-4 xl:py-6 rounded-xl xl:rounded-2xl shadow-lg hover:scale-105 transition-transform text-sm xl:text-base cursor-pointer"
                size="lg"
                disabled={pendingDrawOffer}
              >
                <Handshake className="w-4 h-4 xl:w-5 xl:h-5 mr-2" />
                {pendingDrawOffer ? 'Draw Offer Sent' : 'Offer Draw'}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="elegant-card border-4 border-white/50">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-xl xl:text-2xl font-black bg-gradient-to-r from-blue-500 to-blue-600 bg-clip-text text-transparent">
                  Offer Draw?
                </AlertDialogTitle>
                <AlertDialogDescription className="text-sm xl:text-base font-semibold">
                  {isOnline
                    ? 'Send a draw offer to your opponent. They can accept or decline.'
                    : 'Are you sure you want to declare a draw?'}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="rounded-xl font-bold text-xs xl:text-sm cursor-pointer">
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={onOfferDraw}
                  className="bg-gradient-to-r from-blue-500 to-blue-600 text-white font-bold rounded-xl text-xs xl:text-sm cursor-pointer"
                >
                  {isOnline ? 'Send Offer' : 'Declare Draw'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {/* Takeback Button */}
          {showTakeback && onRequestTakeback && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white font-bold py-4 xl:py-6 rounded-xl xl:rounded-2xl shadow-lg hover:scale-105 transition-transform text-sm xl:text-base cursor-pointer"
                  size="lg"
                  disabled={pendingTakebackRequest}
                >
                  <Undo2 className="w-4 h-4 xl:w-5 xl:h-5 mr-2" />
                  {pendingTakebackRequest ? 'Takeback Requested' : 'Request Takeback'}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="elegant-card border-4 border-white/50">
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-xl xl:text-2xl font-black bg-gradient-to-r from-purple-500 to-purple-600 bg-clip-text text-transparent">
                    Request Takeback?
                  </AlertDialogTitle>
                  <AlertDialogDescription className="text-sm xl:text-base font-semibold">
                    {isOnline
                      ? 'Request to undo your last move. Your opponent must approve.'
                      : 'Undo the last move.'}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="rounded-xl font-bold text-xs xl:text-sm cursor-pointer">
                    Cancel
                  </AlertDialogCancel>
                  <AlertDialogAction
                    onClick={onRequestTakeback}
                    className="bg-gradient-to-r from-purple-500 to-purple-600 text-white font-bold rounded-xl text-xs xl:text-sm cursor-pointer"
                  >
                    {isOnline ? 'Send Request' : 'Undo Move'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
