import { useState } from 'react';
import type { ChessPiece, Position } from '@/types/types';

interface ChessBoardProps {
  board: (ChessPiece | null)[][];
  onMove: (from: Position, to: Position) => void;
  validMoves: Position[];
  selectedSquare: Position | null;
  onSquareClick: (pos: Position) => void;
  isFlipped?: boolean;
}

const PIECE_IMAGES: Record<string, string> = {
  // White pieces - vibrant anime ninja characters
  'white-king': 'https://miaoda-site-img.s3cdn.medo.dev/images/fe45d3bf-1611-4ed4-8fba-96ead8e13bcf.jpg',
  'white-queen': 'https://miaoda-site-img.s3cdn.medo.dev/images/a038df42-9d2c-46ff-900e-4b9f8d6baacd.jpg',
  'white-rook': 'https://miaoda-site-img.s3cdn.medo.dev/images/a4ac85f3-112b-4e7a-b420-cb9b95ab4510.jpg',
  'white-bishop': 'https://miaoda-site-img.s3cdn.medo.dev/images/eb5ee9cb-747d-4bfe-a3ac-8dabedf0fad0.jpg',
  'white-knight': 'https://miaoda-site-img.s3cdn.medo.dev/images/a374560c-6b4e-489b-9c71-80523f94ba7c.jpg',
  'white-pawn': 'https://miaoda-site-img.s3cdn.medo.dev/images/4353883b-f32f-4898-b683-782045c345c3.jpg',
  // Black pieces - same characters with darker styling
  'black-king': 'https://miaoda-site-img.s3cdn.medo.dev/images/fe45d3bf-1611-4ed4-8fba-96ead8e13bcf.jpg',
  'black-queen': 'https://miaoda-site-img.s3cdn.medo.dev/images/a038df42-9d2c-46ff-900e-4b9f8d6baacd.jpg',
  'black-rook': 'https://miaoda-site-img.s3cdn.medo.dev/images/a4ac85f3-112b-4e7a-b420-cb9b95ab4510.jpg',
  'black-bishop': 'https://miaoda-site-img.s3cdn.medo.dev/images/eb5ee9cb-747d-4bfe-a3ac-8dabedf0fad0.jpg',
  'black-knight': 'https://miaoda-site-img.s3cdn.medo.dev/images/a374560c-6b4e-489b-9c71-80523f94ba7c.jpg',
  'black-pawn': 'https://miaoda-site-img.s3cdn.medo.dev/images/4353883b-f32f-4898-b683-782045c345c3.jpg',
};

const CHARACTER_NAMES: Record<string, string> = {
  'king': '👑 Naruto',
  'queen': '⚡ Sasuke',
  'rook': '🏜️ Gaara',
  'bishop': '📖 Kakashi',
  'knight': '💪 Rock Lee',
  'pawn': '🍥 Clone',
};

export default function ChessBoard({
  board,
  onMove,
  validMoves,
  selectedSquare,
  onSquareClick,
  isFlipped = false,
}: ChessBoardProps) {
  const [draggedPiece, setDraggedPiece] = useState<{ piece: ChessPiece; from: Position } | null>(null);
  const [internalSelectedSquare, setInternalSelectedSquare] = useState<Position | null>(null);
  const [internalValidMoves, setInternalValidMoves] = useState<Position[]>([]);
  const [lastMove, setLastMove] = useState<{ from: Position; to: Position } | null>(null);
  const [animatingPiece, setAnimatingPiece] = useState<Position | null>(null);

  if (!board || board.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 text-muted-foreground">
        <p className="text-lg font-bold">Loading board...</p>
      </div>
    );
  }

  const currentSelectedSquare = selectedSquare || internalSelectedSquare;
  const currentValidMoves = validMoves.length > 0 ? validMoves : internalValidMoves;

  const handleSquareClick = (row: number, col: number) => {
    const piece = board?.[row]?.[col];
    
    // If a square is already selected
    if (currentSelectedSquare) {
      // Check if clicking on a valid move
      const isValidMoveSquare = currentValidMoves.some(
        (move) => move.row === row && move.col === col
      );
      
      if (isValidMoveSquare) {
        // Trigger animation
        setAnimatingPiece({ row, col });
        setLastMove({ from: currentSelectedSquare, to: { row, col } });
        
        // Execute the move
        onMove(currentSelectedSquare, { row, col });
        setInternalSelectedSquare(null);
        setInternalValidMoves([]);
        
        // Clear animation after delay
        setTimeout(() => setAnimatingPiece(null), 500);
      } else if (piece && currentSelectedSquare.row === row && currentSelectedSquare.col === col) {
        // Clicking same piece - deselect
        setInternalSelectedSquare(null);
        setInternalValidMoves([]);
      } else if (piece) {
        // Clicking different piece - select it
        setInternalSelectedSquare({ row, col });
        onSquareClick({ row, col });
      } else {
        // Clicking empty square - deselect
        setInternalSelectedSquare(null);
        setInternalValidMoves([]);
      }
    } else if (piece) {
      // No square selected - select this piece
      setInternalSelectedSquare({ row, col });
      onSquareClick({ row, col });
    }
  };

  const isValidMove = (row: number, col: number) => {
    return currentValidMoves.some((move) => move.row === row && move.col === col);
  };

  const isSelected = (row: number, col: number) => {
    return currentSelectedSquare?.row === row && currentSelectedSquare?.col === col;
  };

  const handleDragStart = (e: React.DragEvent, piece: ChessPiece, row: number, col: number) => {
    setDraggedPiece({ piece, from: { row, col } });
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, row: number, col: number) => {
    e.preventDefault();
    if (draggedPiece) {
      onMove(draggedPiece.from, { row, col });
      setDraggedPiece(null);
    }
  };

  const renderSquare = (row: number, col: number) => {
    const displayRow = isFlipped ? 7 - row : row;
    const displayCol = isFlipped ? 7 - col : col;
    const piece = board?.[displayRow]?.[displayCol] || null;
    const isLight = (displayRow + displayCol) % 2 === 0;
    const selected = isSelected(displayRow, displayCol);
    const validMove = isValidMove(displayRow, displayCol);
    const isLastMoveSquare = lastMove && (
      (lastMove.from.row === displayRow && lastMove.from.col === displayCol) ||
      (lastMove.to.row === displayRow && lastMove.to.col === displayCol)
    );

    const squareClass = `
      board-square
      w-full h-full
      flex items-center justify-center
      cursor-pointer
      relative
      transition-all duration-300
      ${isLight ? 'bg-board-light' : 'bg-board-dark'}
      ${selected ? 'ring-4 ring-board-selected shadow-[0_0_30px_rgba(255,165,0,0.8)] scale-105' : ''}
      ${validMove ? 'ring-4 ring-board-highlight shadow-[0_0_20px_rgba(0,255,0,0.6)]' : ''}
      ${isLastMoveSquare ? 'bg-yellow-200/30 dark:bg-yellow-500/20' : ''}
      hover:brightness-110
    `;

    return (
      <div
        key={`${row}-${col}`}
        className={squareClass}
        onClick={() => handleSquareClick(displayRow, displayCol)}
        onDragOver={handleDragOver}
        onDrop={(e) => handleDrop(e, displayRow, displayCol)}
      >
        {validMove && !piece && (
          <div className="w-6 h-6 rounded-full bg-board-highlight opacity-70 animate-pulse shadow-[0_0_15px_rgba(0,255,0,0.8)]" />
        )}
        {piece && (
          <div
            className={`
              piece-move w-full h-full flex items-center justify-center group
              ${animatingPiece?.row === displayRow && animatingPiece?.col === displayCol ? 'animate-piece-slide' : ''}
              ${lastMove?.to.row === displayRow && lastMove?.to.col === displayCol ? 'animate-victory-bounce' : ''}
            `}
            draggable
            onDragStart={(e) => handleDragStart(e, piece, displayRow, displayCol)}
          >
            <div className="relative w-full h-full flex items-center justify-center">
              {/* Outer glow ring */}
              <div 
                className={`
                  absolute inset-0 rounded-full blur-xl
                  ${piece.color === 'white' 
                    ? 'bg-gradient-to-br from-orange-400 via-yellow-300 to-orange-500' 
                    : 'bg-gradient-to-br from-blue-500 via-purple-500 to-indigo-600'}
                  opacity-40
                  ${selected ? 'opacity-80 animate-pulse' : ''}
                  transition-all duration-500
                `}
              />
              
              {/* Main piece container with cartoon border */}
              <div 
                className={`
                  absolute inset-[6%] rounded-full 
                  ${piece.color === 'white' 
                    ? 'bg-gradient-to-br from-white via-orange-50 to-white' 
                    : 'bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900'}
                  shadow-[0_8px_32px_rgba(0,0,0,0.4)]
                  transition-all duration-500
                  ${selected 
                    ? 'scale-110 shadow-[0_0_40px_rgba(255,165,0,1),0_0_80px_rgba(255,165,0,0.6)] ring-[6px] ring-orange-400' 
                    : 'scale-100'}
                `}
                style={{
                  border: piece.color === 'white' 
                    ? '5px solid rgba(255,255,255,1)' 
                    : '5px solid rgba(15,23,42,1)',
                }}
              />
              
              {/* Character image - HUGE and VISIBLE */}
              <img
                src={PIECE_IMAGES[`${piece.color}-${piece.type}`]}
                alt={`${piece.color} ${piece.type}`}
                className={`
                  relative z-20
                  w-[92%] h-[92%] rounded-full object-cover
                  transition-all duration-500
                  ${selected ? 'scale-110 brightness-110' : 'scale-100'}
                `}
                style={{
                  border: piece.color === 'white' 
                    ? '6px solid rgba(255,255,255,1)' 
                    : '6px solid rgba(15,23,42,1)',
                  boxShadow: piece.color === 'white'
                    ? '0 12px 40px rgba(0,0,0,0.4), inset 0 4px 12px rgba(255,255,255,0.6), 0 0 20px rgba(255,165,0,0.5)'
                    : '0 12px 40px rgba(0,0,0,0.6), inset 0 4px 12px rgba(255,255,255,0.2), 0 0 20px rgba(59,130,246,0.5)',
                  filter: 'contrast(1.1) saturate(1.2)',
                }}
                onError={(e) => {
                  console.error(`Failed to load image for ${piece.color} ${piece.type}`);
                  e.currentTarget.style.display = 'none';
                }}
              />
              
              {/* Piece Type Label - ALWAYS VISIBLE for King, Queen, Knight, Rook, Bishop */}
              {piece.type !== 'pawn' && (
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 z-30 pointer-events-none">
                  <div className={`
                    px-2 xl:px-3 py-1 xl:py-1 rounded-full text-[10px] xl:text-xs font-black shadow-2xl whitespace-nowrap border-2 xl:border-3
                    ${piece.color === 'white' 
                      ? 'bg-gradient-to-r from-orange-400 to-red-500 text-white border-white/70' 
                      : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white border-white/70'}
                  `}
                  style={{
                    textShadow: '1px 1px 3px rgba(0,0,0,0.8), 0 0 8px rgba(255,255,255,0.5)',
                  }}>
                    {piece.type.toUpperCase()}
                  </div>
                </div>
              )}
              
              {/* Selection sparkle effect */}
              {selected && (
                <>
                  <div className="absolute -inset-2 rounded-full border-[5px] border-orange-400 animate-ping opacity-75 z-0" />
                  <div className="absolute -inset-4 rounded-full border-[3px] border-yellow-300 animate-pulse opacity-50 z-0" />
                  <div className="absolute inset-0 rounded-full bg-gradient-to-br from-orange-400/30 via-transparent to-yellow-300/30 animate-spin-slow z-0" />
                </>
              )}
              
              {/* Character name tooltip - Desktop only */}
              <div className="hidden xl:block absolute -bottom-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 z-30 pointer-events-none">
                <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-1.5 rounded-full text-xs font-black shadow-xl whitespace-nowrap border-2 border-white/50">
                  {CHARACTER_NAMES[piece.type]}
                </div>
              </div>
            </div>
          </div>
        )}
        {validMove && piece && (
          <div className="absolute inset-0 bg-destructive/40 rounded-lg animate-pulse shadow-[0_0_20px_rgba(255,0,0,0.6)]" />
        )}
      </div>
    );
  };

  return (
    <div className="relative w-full">
      <div 
        className="anime-card rounded-2xl xl:rounded-[2rem] p-1 xl:p-8 shadow-[0_20px_60px_rgba(0,0,0,0.3)]"
        style={{
          background: 'linear-gradient(135deg, hsl(var(--card)) 0%, hsl(var(--muted)) 100%)',
          boxShadow: '0 0 40px rgba(255, 165, 0, 0.2), 0 20px 60px rgba(0, 0, 0, 0.3)',
        }}
      >
        <div className="aspect-square w-full max-w-[98vw] xl:max-w-3xl mx-auto">
          <div className="grid grid-cols-8 grid-rows-8 gap-0 w-full h-full border-[3px] xl:border-[6px] border-primary/40 rounded-xl xl:rounded-3xl overflow-hidden shadow-[0_0_30px_rgba(255,165,0,0.4)]">
            {Array.from({ length: 8 }, (_, row) =>
              Array.from({ length: 8 }, (_, col) => renderSquare(row, col))
            )}
          </div>
        </div>
        
        {/* Coordinate labels - BIGGER ON MOBILE */}
        <div className="flex justify-around mt-1 xl:mt-4 px-1 xl:px-4">
          {['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map((letter, i) => (
            <div key={letter} className="text-xs xl:text-sm font-black text-primary/80 drop-shadow-md">
              {isFlipped ? ['H', 'G', 'F', 'E', 'D', 'C', 'B', 'A'][i] : letter}
            </div>
          ))}
        </div>
      </div>
      
      {/* Character Legend */}
      <div className="mt-3 xl:mt-6 grid grid-cols-2 xl:grid-cols-6 gap-2 xl:gap-3">
        {Object.entries(CHARACTER_NAMES).map(([type, name]) => (
          <div 
            key={type} 
            className="flex items-center gap-2 p-2 xl:p-3 rounded-xl xl:rounded-2xl bg-gradient-to-br from-card to-muted border-2 border-primary/30 shadow-lg hover:shadow-[0_0_20px_rgba(255,165,0,0.4)] transition-all duration-300 hover:scale-105"
          >
            <img
              src={PIECE_IMAGES[`white-${type}`]}
              alt={type}
              className="w-8 h-8 xl:w-10 xl:h-10 object-contain drop-shadow-md"
            />
            <span className="text-xs xl:text-xs font-black text-foreground">{name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
