import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Undo2, Redo2, RotateCcw, Flag, Save, Volume2, VolumeX, Music, Music2 } from 'lucide-react';

interface GameControlsProps {
  onUndo: () => void;
  onRedo: () => void;
  onReset: () => void;
  onResign: () => void;
  onSave: () => void;
  canUndo: boolean;
  canRedo: boolean;
  soundEnabled: boolean;
  musicEnabled: boolean;
  onToggleSound: () => void;
  onToggleMusic: () => void;
}

export function GameControls({
  onUndo,
  onRedo,
  onReset,
  onResign,
  onSave,
  canUndo,
  canRedo,
  soundEnabled,
  musicEnabled,
  onToggleSound,
  onToggleMusic,
}: GameControlsProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-2 xl:grid-cols-3 gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onUndo}
            disabled={!canUndo}
            className="flex items-center gap-2"
          >
            <Undo2 className="w-4 h-4" />
            <span className="hidden xl:inline">Undo</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onRedo}
            disabled={!canRedo}
            className="flex items-center gap-2"
          >
            <Redo2 className="w-4 h-4" />
            <span className="hidden xl:inline">Redo</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onReset}
            className="flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span className="hidden xl:inline">Reset</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onResign}
            className="flex items-center gap-2"
          >
            <Flag className="w-4 h-4" />
            <span className="hidden xl:inline">Resign</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onSave}
            className="flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span className="hidden xl:inline">Save</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onToggleSound}
            className="flex items-center gap-2"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden xl:inline">Sound</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onToggleMusic}
            className="flex items-center gap-2 col-span-2 xl:col-span-3"
          >
            {musicEnabled ? <Music className="w-4 h-4" /> : <Music2 className="w-4 h-4" />}
            <span className="hidden xl:inline">Background Music</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
