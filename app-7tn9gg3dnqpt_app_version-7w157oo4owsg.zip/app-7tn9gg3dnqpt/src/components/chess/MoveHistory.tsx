import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Move } from '@/types/types';
import { moveToNotation } from '@/lib/chess/notation';

interface MoveHistoryProps {
  moves: Move[];
  currentMoveIndex?: number;
  onMoveClick?: (index: number) => void;
}

export function MoveHistory({ moves, currentMoveIndex, onMoveClick }: MoveHistoryProps) {
  const movePairs: { white: Move | null; black: Move | null; moveNumber: number }[] = [];

  for (let i = 0; i < moves.length; i += 2) {
    movePairs.push({
      white: moves[i] || null,
      black: moves[i + 1] || null,
      moveNumber: Math.floor(i / 2) + 1,
    });
  }

  const formatMove = (move: Move, index: number): string => {
    const nextMove = moves[index + 1];
    const isCapture = !!move.captured;
    const isCheck = false;
    const isCheckmate = false;

    return moveToNotation(move, isCapture, isCheck, isCheckmate);
  };

  return (
    <Card className="w-full h-full">
      <CardHeader className="pb-2 xl:pb-3 px-3 xl:px-6 pt-3 xl:pt-6">
        <CardTitle className="text-base xl:text-xl">Move History</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[150px] xl:h-[400px] px-3 xl:px-4">
          {movePairs.length === 0 ? (
            <p className="text-muted-foreground text-xs xl:text-sm py-3 xl:py-4">No moves yet</p>
          ) : (
            <div className="space-y-1">
              {movePairs.map((pair, pairIndex) => (
                <div
                  key={pairIndex}
                  className="flex items-center gap-2 text-xs xl:text-sm hover:bg-muted/50 rounded px-2 py-1"
                >
                  <span className="text-muted-foreground font-semibold w-6 xl:w-8">
                    {pair.moveNumber}.
                  </span>
                  {pair.white && (
                    <button
                      type="button"
                      className="flex-1 text-left hover:text-primary transition-colors"
                      onClick={() => onMoveClick?.(pairIndex * 2)}
                    >
                      {formatMove(pair.white, pairIndex * 2)}
                    </button>
                  )}
                  {pair.black && (
                    <button
                      type="button"
                      className="flex-1 text-left hover:text-primary transition-colors"
                      onClick={() => onMoveClick?.(pairIndex * 2 + 1)}
                    >
                      {formatMove(pair.black, pairIndex * 2 + 1)}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
