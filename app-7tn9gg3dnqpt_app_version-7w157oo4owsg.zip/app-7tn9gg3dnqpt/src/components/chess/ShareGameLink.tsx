import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Copy, Check, Share2, QrCode } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ShareGameLinkProps {
  gameCode: string;
}

export default function ShareGameLink({ gameCode }: ShareGameLinkProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const gameUrl = `${window.location.origin}/game/online?code=${gameCode}`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(gameUrl);
      setCopied(true);
      toast({
        title: '✅ Link Copied!',
        description: 'Share this link with your friend!',
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        title: '❌ Copy Failed',
        description: 'Please copy the link manually',
        variant: 'destructive',
      });
    }
  };

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(gameCode);
      toast({
        title: '✅ Code Copied!',
        description: 'Share this code with your friend!',
      });
    } catch (error) {
      toast({
        title: '❌ Copy Failed',
        description: 'Please copy the code manually',
        variant: 'destructive',
      });
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join my Naruto Chess Game!',
          text: `Let's play Naruto Chess! Use code: ${gameCode}`,
          url: gameUrl,
        });
      } catch (error) {
        // User cancelled share or error occurred
      }
    } else {
      handleCopyLink();
    }
  };

  return (
    <Card className="border-4 border-white/50 rounded-3xl overflow-hidden elegant-card">
      <CardContent className="p-4 xl:p-6">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Share2 className="w-6 h-6 text-orange-500" />
          <h3 className="text-lg xl:text-xl font-black text-center bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
            Share Game
          </h3>
        </div>

        {/* Game Code Display */}
        <div className="mb-4">
          <p className="text-sm font-semibold text-slate-600 dark:text-slate-400 mb-2 text-center">
            Game Code
          </p>
          <div className="flex gap-2">
            <div className="flex-1 bg-gradient-to-r from-orange-100 to-red-100 dark:from-orange-950 dark:to-red-950 rounded-2xl p-4 border-2 border-orange-300 dark:border-orange-700">
              <p className="text-3xl font-black text-center text-orange-600 dark:text-orange-400 tracking-wider">
                {gameCode}
              </p>
            </div>
            <Button
              type="button"
              onClick={handleCopyCode}
              className="bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold rounded-2xl shadow-lg hover:scale-105 transition-transform button-press px-4"
              size="lg"
            >
              <Copy className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Share Link */}
        <div className="mb-4">
          <p className="text-sm font-semibold text-slate-600 dark:text-slate-400 mb-2 text-center">
            Or Share Link
          </p>
          <div className="flex gap-2">
            <Input
              value={gameUrl}
              readOnly
              className="flex-1 rounded-2xl border-2 font-mono text-sm"
            />
            <Button
              type="button"
              onClick={handleCopyLink}
              className="bg-gradient-to-r from-blue-500 to-blue-600 text-white font-bold rounded-2xl shadow-lg hover:scale-105 transition-transform button-press px-4"
              size="lg"
            >
              {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Share Button (for mobile) */}
        {navigator.share && (
          <Button
            type="button"
            onClick={handleShare}
            className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white font-bold py-6 rounded-2xl shadow-lg hover:scale-105 transition-transform button-press"
            size="lg"
          >
            <Share2 className="w-5 h-5 mr-2" />
            Share with Friends
          </Button>
        )}

        {/* Instructions */}
        <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950 rounded-2xl border-2 border-blue-200 dark:border-blue-800">
          <p className="text-sm font-semibold text-blue-800 dark:text-blue-200 text-center">
            💡 Your friend can click the link or enter the code to join!
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
