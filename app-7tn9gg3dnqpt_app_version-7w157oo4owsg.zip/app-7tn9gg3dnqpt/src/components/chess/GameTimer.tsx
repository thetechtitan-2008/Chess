import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface GameTimerProps {
  whiteTime: number;
  blackTime: number;
  currentTurn: 'white' | 'black';
  isActive: boolean;
  onTimeOut: (color: 'white' | 'black') => void;
}

export function GameTimer({ whiteTime, blackTime, currentTurn, isActive, onTimeOut }: GameTimerProps) {
  const [whiteTimeRemaining, setWhiteTimeRemaining] = useState(whiteTime);
  const [blackTimeRemaining, setBlackTimeRemaining] = useState(blackTime);

  useEffect(() => {
    setWhiteTimeRemaining(whiteTime);
    setBlackTimeRemaining(blackTime);
  }, [whiteTime, blackTime]);

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      if (currentTurn === 'white') {
        setWhiteTimeRemaining(prev => {
          if (prev <= 1) {
            onTimeOut('white');
            return 0;
          }
          return prev - 1;
        });
      } else {
        setBlackTimeRemaining(prev => {
          if (prev <= 1) {
            onTimeOut('black');
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, currentTurn, onTimeOut]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card>
      <CardContent className="p-3 xl:p-4">
        <div className="space-y-2 xl:space-y-3">
          <div
            className={cn(
              'flex items-center justify-between p-2 xl:p-3 rounded-lg transition-all',
              currentTurn === 'black' ? 'bg-primary/10 border-2 border-primary' : 'bg-muted'
            )}
          >
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 xl:w-4 xl:h-4 rounded-full bg-foreground" />
              <span className="text-sm xl:text-base font-semibold">Black</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-3 h-3 xl:w-4 xl:h-4" />
              <span className={cn(
                'text-base xl:text-lg font-mono font-bold',
                blackTimeRemaining < 30 && 'text-destructive animate-pulse'
              )}>
                {formatTime(blackTimeRemaining)}
              </span>
            </div>
          </div>

          <div
            className={cn(
              'flex items-center justify-between p-2 xl:p-3 rounded-lg transition-all',
              currentTurn === 'white' ? 'bg-primary/10 border-2 border-primary' : 'bg-muted'
            )}
          >
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 xl:w-4 xl:h-4 rounded-full bg-background border-2 border-foreground" />
              <span className="text-sm xl:text-base font-semibold">White</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-3 h-3 xl:w-4 xl:h-4" />
              <span className={cn(
                'text-base xl:text-lg font-mono font-bold',
                whiteTimeRemaining < 30 && 'text-destructive animate-pulse'
              )}>
                {formatTime(whiteTimeRemaining)}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
