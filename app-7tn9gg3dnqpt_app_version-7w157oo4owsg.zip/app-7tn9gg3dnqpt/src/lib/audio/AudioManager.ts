export class AudioManager {
  private sounds: Map<string, HTMLAudioElement> = new Map();
  private music: HTMLAudioElement | null = null;
  private soundEnabled: boolean = true;
  private musicEnabled: boolean = true;
  private volume: number = 0.5;

  constructor() {
    this.initializeSounds();
  }

  private initializeSounds(): void {
    const soundEffects = {
      move: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
      capture: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
      check: 'https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3',
      checkmate: 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3',
      castle: 'https://assets.mixkit.co/active_storage/sfx/2570/2570-preview.mp3',
    };

    for (const [name, url] of Object.entries(soundEffects)) {
      const audio = new Audio(url);
      audio.volume = this.volume;
      this.sounds.set(name, audio);
    }

    this.music = new Audio('https://assets.mixkit.co/active_storage/sfx/2492/2492-preview.mp3');
    this.music.loop = true;
    this.music.volume = this.volume * 0.3;
  }

  playSound(soundName: string): void {
    if (!this.soundEnabled) return;

    const sound = this.sounds.get(soundName);
    if (sound) {
      sound.currentTime = 0;
      sound.play().catch(() => {});
    }
  }

  playMove(): void {
    this.playSound('move');
  }

  playCapture(): void {
    this.playSound('capture');
  }

  playCheck(): void {
    this.playSound('check');
  }

  playCheckmate(): void {
    this.playSound('checkmate');
  }

  playCastle(): void {
    this.playSound('castle');
  }

  startMusic(): void {
    if (!this.musicEnabled || !this.music) return;
    this.music.play().catch(() => {});
  }

  stopMusic(): void {
    if (!this.music) return;
    this.music.pause();
    this.music.currentTime = 0;
  }

  setSoundEnabled(enabled: boolean): void {
    this.soundEnabled = enabled;
  }

  setMusicEnabled(enabled: boolean): void {
    this.musicEnabled = enabled;
    if (enabled) {
      this.startMusic();
    } else {
      this.stopMusic();
    }
  }

  setVolume(volume: number): void {
    this.volume = Math.max(0, Math.min(1, volume));
    
    for (const sound of this.sounds.values()) {
      sound.volume = this.volume;
    }

    if (this.music) {
      this.music.volume = this.volume * 0.3;
    }
  }

  isSoundEnabled(): boolean {
    return this.soundEnabled;
  }

  isMusicEnabled(): boolean {
    return this.musicEnabled;
  }

  getVolume(): number {
    return this.volume;
  }
}

export const audioManager = new AudioManager();
