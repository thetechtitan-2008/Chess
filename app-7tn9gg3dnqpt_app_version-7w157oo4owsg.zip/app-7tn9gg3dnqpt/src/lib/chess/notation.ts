import type { Position, Move, ChessPiece } from '@/types/types';

export function positionToAlgebraic(pos: Position): string {
  const file = String.fromCharCode(97 + pos.col);
  const rank = 8 - pos.row;
  return `${file}${rank}`;
}

export function algebraicToPosition(algebraic: string): Position {
  const col = algebraic.charCodeAt(0) - 97;
  const row = 8 - Number.parseInt(algebraic[1]);
  return { row, col };
}

export function moveToNotation(move: Move, isCapture: boolean, isCheck: boolean, isCheckmate: boolean): string {
  let notation = '';

  if (move.isCastling) {
    return move.to.col > move.from.col ? 'O-O' : 'O-O-O';
  }

  if (move.piece.type !== 'pawn') {
    notation += pieceToSymbol(move.piece.type);
  }

  notation += positionToAlgebraic(move.from);

  if (isCapture) {
    notation += 'x';
  } else {
    notation += '-';
  }

  notation += positionToAlgebraic(move.to);

  if (move.promotion) {
    notation += '=' + pieceToSymbol(move.promotion);
  }

  if (isCheckmate) {
    notation += '#';
  } else if (isCheck) {
    notation += '+';
  }

  return notation;
}

function pieceToSymbol(type: string): string {
  const symbols: Record<string, string> = {
    king: 'K',
    queen: 'Q',
    rook: 'R',
    bishop: 'B',
    knight: 'N',
    pawn: '',
  };
  return symbols[type] || '';
}

export function getPieceCharacter(piece: ChessPiece): string {
  const characters: Record<string, Record<string, string>> = {
    white: {
      king: '♔',
      queen: '♕',
      rook: '♖',
      bishop: '♗',
      knight: '♘',
      pawn: '♙',
    },
    black: {
      king: '♚',
      queen: '♛',
      rook: '♜',
      bishop: '♝',
      knight: '♞',
      pawn: '♟',
    },
  };
  return characters[piece.color][piece.type] || '';
}
