import type { ChessPiece, Position, Move, GameState, PieceType, PieceColor } from '@/types/types';

export class ChessEngine {
  private state: GameState;

  constructor(initialState?: GameState) {
    this.state = initialState || this.getInitialState();
  }

  private getInitialState(): GameState {
    const board: (ChessPiece | null)[][] = [
      [
        { type: 'rook', color: 'black' },
        { type: 'knight', color: 'black' },
        { type: 'bishop', color: 'black' },
        { type: 'queen', color: 'black' },
        { type: 'king', color: 'black' },
        { type: 'bishop', color: 'black' },
        { type: 'knight', color: 'black' },
        { type: 'rook', color: 'black' },
      ],
      Array(8).fill(null).map(() => ({ type: 'pawn', color: 'black' })),
      Array(8).fill(null),
      Array(8).fill(null),
      Array(8).fill(null),
      Array(8).fill(null),
      Array(8).fill(null).map(() => ({ type: 'pawn', color: 'white' })),
      [
        { type: 'rook', color: 'white' },
        { type: 'knight', color: 'white' },
        { type: 'bishop', color: 'white' },
        { type: 'queen', color: 'white' },
        { type: 'king', color: 'white' },
        { type: 'bishop', color: 'white' },
        { type: 'knight', color: 'white' },
        { type: 'rook', color: 'white' },
      ],
    ];

    return {
      board,
      currentTurn: 'white',
      moveHistory: [],
      isCheck: false,
      isCheckmate: false,
      isStalemate: false,
      enPassantTarget: null,
      castlingRights: {
        whiteKingSide: true,
        whiteQueenSide: true,
        blackKingSide: true,
        blackQueenSide: true,
      },
    };
  }

  getState(): GameState {
    return this.state;
  }

  setState(state: GameState): void {
    this.state = state;
  }

  getPiece(pos: Position): ChessPiece | null {
    if (!this.isValidPosition(pos)) return null;
    return this.state.board[pos.row][pos.col];
  }

  isValidPosition(pos: Position): boolean {
    return pos.row >= 0 && pos.row < 8 && pos.col >= 0 && pos.col < 8;
  }

  getLegalMoves(pos: Position): Position[] {
    const piece = this.getPiece(pos);
    if (!piece || piece.color !== this.state.currentTurn) return [];

    const moves = this.getPseudoLegalMoves(pos, piece);
    return moves.filter(move => !this.wouldBeInCheck(pos, move, piece.color));
  }

  private getPseudoLegalMoves(pos: Position, piece: ChessPiece): Position[] {
    switch (piece.type) {
      case 'pawn':
        return this.getPawnMoves(pos, piece.color);
      case 'knight':
        return this.getKnightMoves(pos, piece.color);
      case 'bishop':
        return this.getBishopMoves(pos, piece.color);
      case 'rook':
        return this.getRookMoves(pos, piece.color);
      case 'queen':
        return this.getQueenMoves(pos, piece.color);
      case 'king':
        return this.getKingMoves(pos, piece.color);
      default:
        return [];
    }
  }

  private getPawnMoves(pos: Position, color: PieceColor): Position[] {
    const moves: Position[] = [];
    const direction = color === 'white' ? -1 : 1;
    const startRow = color === 'white' ? 6 : 1;

    const forward = { row: pos.row + direction, col: pos.col };
    if (this.isValidPosition(forward) && !this.getPiece(forward)) {
      moves.push(forward);

      if (pos.row === startRow) {
        const doubleForward = { row: pos.row + 2 * direction, col: pos.col };
        if (!this.getPiece(doubleForward)) {
          moves.push(doubleForward);
        }
      }
    }

    const captures = [
      { row: pos.row + direction, col: pos.col - 1 },
      { row: pos.row + direction, col: pos.col + 1 },
    ];

    for (const capture of captures) {
      if (this.isValidPosition(capture)) {
        const targetPiece = this.getPiece(capture);
        if (targetPiece && targetPiece.color !== color) {
          moves.push(capture);
        }
        if (this.state.enPassantTarget &&
            capture.row === this.state.enPassantTarget.row &&
            capture.col === this.state.enPassantTarget.col) {
          moves.push(capture);
        }
      }
    }

    return moves;
  }

  private getKnightMoves(pos: Position, color: PieceColor): Position[] {
    const moves: Position[] = [];
    const offsets = [
      [-2, -1], [-2, 1], [-1, -2], [-1, 2],
      [1, -2], [1, 2], [2, -1], [2, 1],
    ];

    for (const [dRow, dCol] of offsets) {
      const newPos = { row: pos.row + dRow, col: pos.col + dCol };
      if (this.isValidPosition(newPos)) {
        const targetPiece = this.getPiece(newPos);
        if (!targetPiece || targetPiece.color !== color) {
          moves.push(newPos);
        }
      }
    }

    return moves;
  }

  private getBishopMoves(pos: Position, color: PieceColor): Position[] {
    return this.getLineMoves(pos, color, [[-1, -1], [-1, 1], [1, -1], [1, 1]]);
  }

  private getRookMoves(pos: Position, color: PieceColor): Position[] {
    return this.getLineMoves(pos, color, [[-1, 0], [1, 0], [0, -1], [0, 1]]);
  }

  private getQueenMoves(pos: Position, color: PieceColor): Position[] {
    return this.getLineMoves(pos, color, [
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1], [0, 1],
      [1, -1], [1, 0], [1, 1],
    ]);
  }

  private getLineMoves(pos: Position, color: PieceColor, directions: number[][]): Position[] {
    const moves: Position[] = [];

    for (const [dRow, dCol] of directions) {
      let newRow = pos.row + dRow;
      let newCol = pos.col + dCol;

      while (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
        const targetPiece = this.getPiece({ row: newRow, col: newCol });
        if (!targetPiece) {
          moves.push({ row: newRow, col: newCol });
        } else {
          if (targetPiece.color !== color) {
            moves.push({ row: newRow, col: newCol });
          }
          break;
        }
        newRow += dRow;
        newCol += dCol;
      }
    }

    return moves;
  }

  private getKingMoves(pos: Position, color: PieceColor): Position[] {
    const moves: Position[] = [];
    const offsets = [
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1], [0, 1],
      [1, -1], [1, 0], [1, 1],
    ];

    for (const [dRow, dCol] of offsets) {
      const newPos = { row: pos.row + dRow, col: pos.col + dCol };
      if (this.isValidPosition(newPos)) {
        const targetPiece = this.getPiece(newPos);
        if (!targetPiece || targetPiece.color !== color) {
          moves.push(newPos);
        }
      }
    }

    const row = color === 'white' ? 7 : 0;
    if (pos.row === row && pos.col === 4) {
      if (this.canCastleKingSide(color)) {
        moves.push({ row, col: 6 });
      }
      if (this.canCastleQueenSide(color)) {
        moves.push({ row, col: 2 });
      }
    }

    return moves;
  }

  private canCastleKingSide(color: PieceColor): boolean {
    const row = color === 'white' ? 7 : 0;
    const rights = color === 'white' ? this.state.castlingRights.whiteKingSide : this.state.castlingRights.blackKingSide;

    if (!rights) return false;

    if (this.getPiece({ row, col: 5 }) || this.getPiece({ row, col: 6 })) {
      return false;
    }

    if (this.isSquareAttacked({ row, col: 4 }, color) ||
        this.isSquareAttacked({ row, col: 5 }, color) ||
        this.isSquareAttacked({ row, col: 6 }, color)) {
      return false;
    }

    return true;
  }

  private canCastleQueenSide(color: PieceColor): boolean {
    const row = color === 'white' ? 7 : 0;
    const rights = color === 'white' ? this.state.castlingRights.whiteQueenSide : this.state.castlingRights.blackQueenSide;

    if (!rights) return false;

    if (this.getPiece({ row, col: 1 }) || this.getPiece({ row, col: 2 }) || this.getPiece({ row, col: 3 })) {
      return false;
    }

    if (this.isSquareAttacked({ row, col: 4 }, color) ||
        this.isSquareAttacked({ row, col: 3 }, color) ||
        this.isSquareAttacked({ row, col: 2 }, color)) {
      return false;
    }

    return true;
  }

  private wouldBeInCheck(from: Position, to: Position, color: PieceColor): boolean {
    const tempBoard = this.state.board.map(row => [...row]);
    tempBoard[to.row][to.col] = tempBoard[from.row][from.col];
    tempBoard[from.row][from.col] = null;

    const kingPos = this.findKing(color, tempBoard);
    if (!kingPos) return true;

    return this.isSquareAttackedOnBoard(kingPos, color, tempBoard);
  }

  private findKing(color: PieceColor, board: (ChessPiece | null)[][] = this.state.board): Position | null {
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = board[row][col];
        if (piece && piece.type === 'king' && piece.color === color) {
          return { row, col };
        }
      }
    }
    return null;
  }

  private isSquareAttacked(pos: Position, defenderColor: PieceColor): boolean {
    return this.isSquareAttackedOnBoard(pos, defenderColor, this.state.board);
  }

  private isSquareAttackedOnBoard(pos: Position, defenderColor: PieceColor, board: (ChessPiece | null)[][]): boolean {
    const attackerColor = defenderColor === 'white' ? 'black' : 'white';

    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = board[row][col];
        if (piece && piece.color === attackerColor) {
          const moves = this.getPseudoLegalMovesOnBoard({ row, col }, piece, board);
          if (moves.some(move => move.row === pos.row && move.col === pos.col)) {
            return true;
          }
        }
      }
    }

    return false;
  }

  private getPseudoLegalMovesOnBoard(pos: Position, piece: ChessPiece, board: (ChessPiece | null)[][]): Position[] {
    switch (piece.type) {
      case 'pawn':
        return this.getPawnMovesOnBoard(pos, piece.color, board);
      case 'knight':
        return this.getKnightMovesOnBoard(pos, piece.color, board);
      case 'bishop':
        return this.getBishopMovesOnBoard(pos, piece.color, board);
      case 'rook':
        return this.getRookMovesOnBoard(pos, piece.color, board);
      case 'queen':
        return this.getQueenMovesOnBoard(pos, piece.color, board);
      case 'king':
        return this.getKingMovesOnBoard(pos, piece.color, board);
      default:
        return [];
    }
  }

  private getPawnMovesOnBoard(pos: Position, color: PieceColor, board: (ChessPiece | null)[][]): Position[] {
    const moves: Position[] = [];
    const direction = color === 'white' ? -1 : 1;

    const captures = [
      { row: pos.row + direction, col: pos.col - 1 },
      { row: pos.row + direction, col: pos.col + 1 },
    ];

    for (const capture of captures) {
      if (this.isValidPosition(capture)) {
        const targetPiece = board[capture.row][capture.col];
        if (targetPiece && targetPiece.color !== color) {
          moves.push(capture);
        }
      }
    }

    return moves;
  }

  private getKnightMovesOnBoard(pos: Position, color: PieceColor, board: (ChessPiece | null)[][]): Position[] {
    const moves: Position[] = [];
    const offsets = [
      [-2, -1], [-2, 1], [-1, -2], [-1, 2],
      [1, -2], [1, 2], [2, -1], [2, 1],
    ];

    for (const [dRow, dCol] of offsets) {
      const newPos = { row: pos.row + dRow, col: pos.col + dCol };
      if (this.isValidPosition(newPos)) {
        const targetPiece = board[newPos.row][newPos.col];
        if (!targetPiece || targetPiece.color !== color) {
          moves.push(newPos);
        }
      }
    }

    return moves;
  }

  private getBishopMovesOnBoard(pos: Position, color: PieceColor, board: (ChessPiece | null)[][]): Position[] {
    return this.getLineMovesOnBoard(pos, color, board, [[-1, -1], [-1, 1], [1, -1], [1, 1]]);
  }

  private getRookMovesOnBoard(pos: Position, color: PieceColor, board: (ChessPiece | null)[][]): Position[] {
    return this.getLineMovesOnBoard(pos, color, board, [[-1, 0], [1, 0], [0, -1], [0, 1]]);
  }

  private getQueenMovesOnBoard(pos: Position, color: PieceColor, board: (ChessPiece | null)[][]): Position[] {
    return this.getLineMovesOnBoard(pos, color, board, [
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1], [0, 1],
      [1, -1], [1, 0], [1, 1],
    ]);
  }

  private getKingMovesOnBoard(pos: Position, color: PieceColor, board: (ChessPiece | null)[][]): Position[] {
    const moves: Position[] = [];
    const offsets = [
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1], [0, 1],
      [1, -1], [1, 0], [1, 1],
    ];

    for (const [dRow, dCol] of offsets) {
      const newPos = { row: pos.row + dRow, col: pos.col + dCol };
      if (this.isValidPosition(newPos)) {
        const targetPiece = board[newPos.row][newPos.col];
        if (!targetPiece || targetPiece.color !== color) {
          moves.push(newPos);
        }
      }
    }

    return moves;
  }

  private getLineMovesOnBoard(pos: Position, color: PieceColor, board: (ChessPiece | null)[][], directions: number[][]): Position[] {
    const moves: Position[] = [];

    for (const [dRow, dCol] of directions) {
      let newRow = pos.row + dRow;
      let newCol = pos.col + dCol;

      while (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
        const targetPiece = board[newRow][newCol];
        if (!targetPiece) {
          moves.push({ row: newRow, col: newCol });
        } else {
          if (targetPiece.color !== color) {
            moves.push({ row: newRow, col: newCol });
          }
          break;
        }
        newRow += dRow;
        newCol += dCol;
      }
    }

    return moves;
  }

  makeMove(from: Position, to: Position, promotion?: PieceType): boolean {
    const piece = this.getPiece(from);
    if (!piece || piece.color !== this.state.currentTurn) return false;

    const legalMoves = this.getLegalMoves(from);
    if (!legalMoves.some(move => move.row === to.row && move.col === to.col)) {
      return false;
    }

    const capturedPiece = this.getPiece(to);
    const isEnPassant = piece.type === 'pawn' &&
                        this.state.enPassantTarget &&
                        to.row === this.state.enPassantTarget.row &&
                        to.col === this.state.enPassantTarget.col;

    const isCastling = piece.type === 'king' && Math.abs(to.col - from.col) === 2;

    this.state.board[to.row][to.col] = this.state.board[from.row][from.col];
    this.state.board[from.row][from.col] = null;

    if (promotion && piece.type === 'pawn' && (to.row === 0 || to.row === 7)) {
      this.state.board[to.row][to.col] = { type: promotion, color: piece.color };
    }

    if (isEnPassant) {
      const captureRow = piece.color === 'white' ? to.row + 1 : to.row - 1;
      this.state.board[captureRow][to.col] = null;
    }

    if (isCastling) {
      const rookFromCol = to.col > from.col ? 7 : 0;
      const rookToCol = to.col > from.col ? 5 : 3;
      this.state.board[to.row][rookToCol] = this.state.board[to.row][rookFromCol];
      this.state.board[to.row][rookFromCol] = null;
    }

    if (piece.type === 'pawn' && Math.abs(to.row - from.row) === 2) {
      this.state.enPassantTarget = {
        row: (from.row + to.row) / 2,
        col: from.col,
      };
    } else {
      this.state.enPassantTarget = null;
    }

    if (piece.type === 'king') {
      if (piece.color === 'white') {
        this.state.castlingRights.whiteKingSide = false;
        this.state.castlingRights.whiteQueenSide = false;
      } else {
        this.state.castlingRights.blackKingSide = false;
        this.state.castlingRights.blackQueenSide = false;
      }
    }

    if (piece.type === 'rook') {
      if (piece.color === 'white') {
        if (from.col === 0) this.state.castlingRights.whiteQueenSide = false;
        if (from.col === 7) this.state.castlingRights.whiteKingSide = false;
      } else {
        if (from.col === 0) this.state.castlingRights.blackQueenSide = false;
        if (from.col === 7) this.state.castlingRights.blackKingSide = false;
      }
    }

    this.state.moveHistory.push({
      from,
      to,
      piece,
      captured: capturedPiece || undefined,
      isEnPassant,
      isCastling,
      promotion,
    });

    this.state.currentTurn = this.state.currentTurn === 'white' ? 'black' : 'white';

    this.updateGameStatus();

    return true;
  }

  private updateGameStatus(): void {
    const kingPos = this.findKing(this.state.currentTurn);
    if (!kingPos) {
      this.state.isCheck = false;
      this.state.isCheckmate = false;
      return;
    }

    this.state.isCheck = this.isSquareAttacked(kingPos, this.state.currentTurn);

    const hasLegalMoves = this.hasAnyLegalMoves(this.state.currentTurn);

    if (!hasLegalMoves) {
      if (this.state.isCheck) {
        this.state.isCheckmate = true;
        this.state.isStalemate = false;
      } else {
        this.state.isStalemate = true;
        this.state.isCheckmate = false;
      }
    } else {
      this.state.isCheckmate = false;
      this.state.isStalemate = false;
    }
  }

  private hasAnyLegalMoves(color: PieceColor): boolean {
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = this.getPiece({ row, col });
        if (piece && piece.color === color) {
          const moves = this.getLegalMoves({ row, col });
          if (moves.length > 0) return true;
        }
      }
    }
    return false;
  }

  undoMove(): boolean {
    if (this.state.moveHistory.length === 0) return false;

    this.state = this.getInitialState();

    const moves = [...this.state.moveHistory];
    this.state.moveHistory = [];

    moves.slice(0, -1).forEach(move => {
      this.makeMove(move.from, move.to, move.promotion);
    });

    return true;
  }

  toFEN(): string {
    let fen = '';

    for (let row = 0; row < 8; row++) {
      let emptyCount = 0;
      for (let col = 0; col < 8; col++) {
        const piece = this.state.board[row][col];
        if (!piece) {
          emptyCount++;
        } else {
          if (emptyCount > 0) {
            fen += emptyCount;
            emptyCount = 0;
          }
          const pieceChar = this.pieceToChar(piece);
          fen += piece.color === 'white' ? pieceChar.toUpperCase() : pieceChar.toLowerCase();
        }
      }
      if (emptyCount > 0) fen += emptyCount;
      if (row < 7) fen += '/';
    }

    fen += ` ${this.state.currentTurn === 'white' ? 'w' : 'b'}`;

    let castling = '';
    if (this.state.castlingRights.whiteKingSide) castling += 'K';
    if (this.state.castlingRights.whiteQueenSide) castling += 'Q';
    if (this.state.castlingRights.blackKingSide) castling += 'k';
    if (this.state.castlingRights.blackQueenSide) castling += 'q';
    fen += ` ${castling || '-'}`;

    if (this.state.enPassantTarget) {
      const file = String.fromCharCode(97 + this.state.enPassantTarget.col);
      const rank = 8 - this.state.enPassantTarget.row;
      fen += ` ${file}${rank}`;
    } else {
      fen += ' -';
    }

    fen += ' 0 1';

    return fen;
  }

  private pieceToChar(piece: ChessPiece): string {
    const chars: Record<PieceType, string> = {
      king: 'k',
      queen: 'q',
      rook: 'r',
      bishop: 'b',
      knight: 'n',
      pawn: 'p',
    };
    return chars[piece.type];
  }

  fromFEN(fen: string): void {
    const parts = fen.split(' ');
    const board: (ChessPiece | null)[][] = Array(8).fill(null).map(() => Array(8).fill(null));

    const rows = parts[0].split('/');
    for (let row = 0; row < 8; row++) {
      let col = 0;
      for (const char of rows[row]) {
        if (char >= '1' && char <= '8') {
          col += Number.parseInt(char);
        } else {
          board[row][col] = this.charToPiece(char);
          col++;
        }
      }
    }

    this.state.board = board;
    this.state.currentTurn = parts[1] === 'w' ? 'white' : 'black';

    const castling = parts[2];
    this.state.castlingRights = {
      whiteKingSide: castling.includes('K'),
      whiteQueenSide: castling.includes('Q'),
      blackKingSide: castling.includes('k'),
      blackQueenSide: castling.includes('q'),
    };

    if (parts[3] !== '-') {
      const col = parts[3].charCodeAt(0) - 97;
      const row = 8 - Number.parseInt(parts[3][1]);
      this.state.enPassantTarget = { row, col };
    } else {
      this.state.enPassantTarget = null;
    }

    this.updateGameStatus();
  }

  private charToPiece(char: string): ChessPiece {
    const color: PieceColor = char === char.toUpperCase() ? 'white' : 'black';
    const lowerChar = char.toLowerCase();

    const types: Record<string, PieceType> = {
      k: 'king',
      q: 'queen',
      r: 'rook',
      b: 'bishop',
      n: 'knight',
      p: 'pawn',
    };

    return { type: types[lowerChar], color };
  }
}
