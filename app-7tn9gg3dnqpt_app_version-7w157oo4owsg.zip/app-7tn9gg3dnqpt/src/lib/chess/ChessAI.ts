import { ChessEngine } from './ChessEngine';
import type { Position, ChessPiece, PieceColor, Difficulty } from '@/types/types';

interface EvaluatedMove {
  from: Position;
  to: Position;
  score: number;
}

export class ChessAI {
  private engine: ChessEngine;
  private difficulty: Difficulty;
  private maxDepth: number;

  constructor(engine: ChessEngine, difficulty: Difficulty = 'medium') {
    this.engine = engine;
    this.difficulty = difficulty;
    this.maxDepth = this.getDepthForDifficulty(difficulty);
  }

  private getDepthForDifficulty(difficulty: Difficulty): number {
    switch (difficulty) {
      case 'easy':
        return 1;
      case 'medium':
        return 2;
      case 'hard':
        return 3;
      case 'expert':
        return 4;
      default:
        return 2;
    }
  }

  setDifficulty(difficulty: Difficulty): void {
    this.difficulty = difficulty;
    this.maxDepth = this.getDepthForDifficulty(difficulty);
  }

  getBestMove(): { from: Position; to: Position } | null {
    const state = this.engine.getState();
    const color = state.currentTurn;

    if (this.difficulty === 'easy' && Math.random() < 0.3) {
      return this.getRandomMove(color);
    }

    const allMoves = this.getAllPossibleMoves(color);
    if (allMoves.length === 0) return null;

    let bestMove: EvaluatedMove | null = null;
    let bestScore = -Infinity;
    let alpha = -Infinity;
    const beta = Infinity;

    for (const move of allMoves) {
      const tempEngine = new ChessEngine(JSON.parse(JSON.stringify(state)));
      tempEngine.makeMove(move.from, move.to);

      const score = -this.minimax(tempEngine, this.maxDepth - 1, -beta, -alpha, false);

      if (score > bestScore) {
        bestScore = score;
        bestMove = { ...move, score };
      }

      alpha = Math.max(alpha, score);
    }

    return bestMove ? { from: bestMove.from, to: bestMove.to } : null;
  }

  private minimax(
    engine: ChessEngine,
    depth: number,
    alpha: number,
    beta: number,
    isMaximizing: boolean
  ): number {
    const state = engine.getState();

    if (depth === 0 || state.isCheckmate || state.isStalemate) {
      return this.evaluatePosition(engine);
    }

    const color = state.currentTurn;
    const moves = this.getAllPossibleMoves(color);

    if (moves.length === 0) {
      return this.evaluatePosition(engine);
    }

    if (isMaximizing) {
      let maxScore = -Infinity;
      for (const move of moves) {
        const tempEngine = new ChessEngine(JSON.parse(JSON.stringify(state)));
        tempEngine.makeMove(move.from, move.to);
        const score = this.minimax(tempEngine, depth - 1, alpha, beta, false);
        maxScore = Math.max(maxScore, score);
        alpha = Math.max(alpha, score);
        if (beta <= alpha) break;
      }
      return maxScore;
    } else {
      let minScore = Infinity;
      for (const move of moves) {
        const tempEngine = new ChessEngine(JSON.parse(JSON.stringify(state)));
        tempEngine.makeMove(move.from, move.to);
        const score = this.minimax(tempEngine, depth - 1, alpha, beta, true);
        minScore = Math.min(minScore, score);
        beta = Math.min(beta, score);
        if (beta <= alpha) break;
      }
      return minScore;
    }
  }

  private evaluatePosition(engine: ChessEngine): number {
    const state = engine.getState();

    if (state.isCheckmate) {
      return state.currentTurn === 'black' ? 10000 : -10000;
    }

    if (state.isStalemate) {
      return 0;
    }

    let score = 0;

    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = state.board[row][col];
        if (piece) {
          const pieceValue = this.getPieceValue(piece, { row, col });
          score += piece.color === 'black' ? pieceValue : -pieceValue;
        }
      }
    }

    if (state.isCheck) {
      score += state.currentTurn === 'black' ? -50 : 50;
    }

    const blackMobility = this.getMobility(engine, 'black');
    const whiteMobility = this.getMobility(engine, 'white');
    score += (blackMobility - whiteMobility) * 0.1;

    return score;
  }

  private getPieceValue(piece: ChessPiece, pos: Position): number {
    const baseValues: Record<string, number> = {
      pawn: 100,
      knight: 320,
      bishop: 330,
      rook: 500,
      queen: 900,
      king: 20000,
    };

    let value = baseValues[piece.type];

    const positionBonus = this.getPositionBonus(piece, pos);
    value += positionBonus;

    return value;
  }

  private getPositionBonus(piece: ChessPiece, pos: Position): number {
    const pawnTable = [
      [0, 0, 0, 0, 0, 0, 0, 0],
      [50, 50, 50, 50, 50, 50, 50, 50],
      [10, 10, 20, 30, 30, 20, 10, 10],
      [5, 5, 10, 25, 25, 10, 5, 5],
      [0, 0, 0, 20, 20, 0, 0, 0],
      [5, -5, -10, 0, 0, -10, -5, 5],
      [5, 10, 10, -20, -20, 10, 10, 5],
      [0, 0, 0, 0, 0, 0, 0, 0],
    ];

    const knightTable = [
      [-50, -40, -30, -30, -30, -30, -40, -50],
      [-40, -20, 0, 0, 0, 0, -20, -40],
      [-30, 0, 10, 15, 15, 10, 0, -30],
      [-30, 5, 15, 20, 20, 15, 5, -30],
      [-30, 0, 15, 20, 20, 15, 0, -30],
      [-30, 5, 10, 15, 15, 10, 5, -30],
      [-40, -20, 0, 5, 5, 0, -20, -40],
      [-50, -40, -30, -30, -30, -30, -40, -50],
    ];

    const bishopTable = [
      [-20, -10, -10, -10, -10, -10, -10, -20],
      [-10, 0, 0, 0, 0, 0, 0, -10],
      [-10, 0, 5, 10, 10, 5, 0, -10],
      [-10, 5, 5, 10, 10, 5, 5, -10],
      [-10, 0, 10, 10, 10, 10, 0, -10],
      [-10, 10, 10, 10, 10, 10, 10, -10],
      [-10, 5, 0, 0, 0, 0, 5, -10],
      [-20, -10, -10, -10, -10, -10, -10, -20],
    ];

    const row = piece.color === 'white' ? 7 - pos.row : pos.row;
    const col = pos.col;

    switch (piece.type) {
      case 'pawn':
        return pawnTable[row][col];
      case 'knight':
        return knightTable[row][col];
      case 'bishop':
        return bishopTable[row][col];
      case 'king':
        return this.getKingPositionBonus(pos, piece.color);
      default:
        return 0;
    }
  }

  private getKingPositionBonus(pos: Position, color: PieceColor): number {
    const row = color === 'white' ? pos.row : 7 - pos.row;

    if (row >= 6) {
      if (pos.col <= 2 || pos.col >= 5) {
        return 20;
      }
    }

    return -30;
  }

  private getMobility(engine: ChessEngine, color: PieceColor): number {
    let mobility = 0;
    const state = engine.getState();

    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = state.board[row][col];
        if (piece && piece.color === color) {
          mobility += engine.getLegalMoves({ row, col }).length;
        }
      }
    }

    return mobility;
  }

  private getAllPossibleMoves(color: PieceColor): { from: Position; to: Position }[] {
    const moves: { from: Position; to: Position }[] = [];
    const state = this.engine.getState();

    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = state.board[row][col];
        if (piece && piece.color === color) {
          const legalMoves = this.engine.getLegalMoves({ row, col });
          for (const to of legalMoves) {
            moves.push({ from: { row, col }, to });
          }
        }
      }
    }

    return moves;
  }

  private getRandomMove(color: PieceColor): { from: Position; to: Position } | null {
    const allMoves = this.getAllPossibleMoves(color);
    if (allMoves.length === 0) return null;

    const randomIndex = Math.floor(Math.random() * allMoves.length);
    return allMoves[randomIndex];
  }
}
