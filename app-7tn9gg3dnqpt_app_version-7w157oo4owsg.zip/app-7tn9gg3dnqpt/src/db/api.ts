import { supabase } from './supabase';
import type { OnlineGame, GameMove, SavedGame } from '@/types/types';

export const createOnlineGame = async (gameData: Partial<OnlineGame>) => {
  const { data, error } = await supabase
    .from('online_games')
    .insert([gameData])
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const getOnlineGame = async (gameId: string) => {
  const { data, error } = await supabase
    .from('online_games')
    .select('*')
    .eq('id', gameId)
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const updateOnlineGame = async (gameId: string, updates: Partial<OnlineGame>) => {
  const { data, error } = await supabase
    .from('online_games')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', gameId)
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const findWaitingGame = async (gameMode: string) => {
  const { data, error } = await supabase
    .from('online_games')
    .select('*')
    .eq('status', 'waiting')
    .eq('game_mode', gameMode)
    .is('game_code', null)
    .order('created_at', { ascending: true })
    .limit(1)
    .maybeSingle();

  if (error && error.code !== 'PGRST116') throw error;
  return data;
};

export const getGameByCode = async (gameCode: string) => {
  const { data, error } = await supabase
    .from('online_games')
    .select('*')
    .eq('game_code', gameCode)
    .maybeSingle();

  if (error && error.code !== 'PGRST116') throw error;
  return data;
};

export const subscribeToGame = (gameId: string, callback: (payload: any) => void) => {
  return supabase
    .channel(`game:${gameId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'online_games',
        filter: `id=eq.${gameId}`,
      },
      callback
    )
    .subscribe();
};

export const addGameMove = async (moveData: Partial<GameMove>) => {
  const { data, error } = await supabase
    .from('game_moves')
    .insert([moveData])
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const getGameMoves = async (gameId: string) => {
  const { data, error } = await supabase
    .from('game_moves')
    .select('*')
    .eq('game_id', gameId)
    .order('move_number', { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const saveGame = async (gameData: Partial<SavedGame>) => {
  const { data, error } = await supabase
    .from('saved_games')
    .insert([gameData])
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const updateSavedGame = async (gameId: string, updates: Partial<SavedGame>) => {
  const { data, error } = await supabase
    .from('saved_games')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', gameId)
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const getSavedGames = async (playerId: string) => {
  const { data, error } = await supabase
    .from('saved_games')
    .select('*')
    .eq('player_id', playerId)
    .order('updated_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const deleteSavedGame = async (gameId: string) => {
  const { error } = await supabase
    .from('saved_games')
    .delete()
    .eq('id', gameId);

  if (error) throw error;
};
