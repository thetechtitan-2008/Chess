import HomePage from './pages/HomePage';
import AIGamePage from './pages/AIGamePage';
import LocalGamePage from './pages/LocalGamePage';
import OnlineGamePage from './pages/OnlineGamePage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <HomePage />,
    visible: false,
  },
  {
    name: 'AI Game',
    path: '/game/ai',
    element: <AIGamePage />,
    visible: false,
  },
  {
    name: 'Local Game',
    path: '/game/local',
    element: <LocalGamePage />,
    visible: false,
  },
  {
    name: 'Online Game',
    path: '/game/online',
    element: <OnlineGamePage />,
    visible: false,
  },
];

export default routes;