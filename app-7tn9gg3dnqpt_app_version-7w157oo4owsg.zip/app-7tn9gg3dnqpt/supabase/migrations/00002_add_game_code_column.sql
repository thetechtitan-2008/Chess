/*
# Add game_code column for private games

1. Changes
  - Add `game_code` column to `online_games` table (text, nullable, unique)
  - This allows players to create private games and share a code with friends

2. Notes
  - Game code is optional - null for random matchmaking, set for private games
  - Unique constraint ensures no duplicate codes
*/

ALTER TABLE online_games ADD COLUMN IF NOT EXISTS game_code text UNIQUE;