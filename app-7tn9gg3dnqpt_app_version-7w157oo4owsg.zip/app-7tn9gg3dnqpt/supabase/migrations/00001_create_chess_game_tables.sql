/*
# Create Chess Game Tables

1. New Tables
- `online_games`
  - `id` (uuid, primary key)
  - `white_player_id` (text, nullable for anonymous players)
  - `black_player_id` (text, nullable)
  - `current_fen` (text, stores board state in FEN notation)
  - `game_mode` (text, e.g., 'bullet', 'blitz', 'rapid', 'classical')
  - `time_control` (integer, time in seconds)
  - `white_time_remaining` (integer, seconds)
  - `black_time_remaining` (integer, seconds)
  - `current_turn` (text, 'white' or 'black')
  - `status` (text, 'waiting', 'active', 'completed', 'abandoned')
  - `winner` (text, nullable, 'white', 'black', 'draw')
  - `result_reason` (text, nullable, 'checkmate', 'timeout', 'resignation', 'draw_agreement', 'stalemate')
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

- `game_moves`
  - `id` (uuid, primary key)
  - `game_id` (uuid, references online_games)
  - `move_number` (integer)
  - `move_notation` (text, algebraic notation)
  - `from_square` (text)
  - `to_square` (text)
  - `piece` (text)
  - `captured_piece` (text, nullable)
  - `is_check` (boolean)
  - `is_checkmate` (boolean)
  - `fen_after_move` (text)
  - `timestamp` (timestamptz)

- `saved_games`
  - `id` (uuid, primary key)
  - `player_id` (text)
  - `game_name` (text)
  - `game_mode` (text)
  - `current_fen` (text)
  - `move_history` (jsonb, array of moves)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

2. Security
- No RLS enabled - public access for all players
- All tables are publicly readable and writable for game functionality

3. Notes
- Using FEN (Forsyth-Edwards Notation) for efficient board state storage
- Supporting anonymous players with text IDs instead of auth.users references
- Real-time subscriptions will be used for online multiplayer
*/

CREATE TABLE IF NOT EXISTS online_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  white_player_id text,
  black_player_id text,
  current_fen text NOT NULL DEFAULT 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  game_mode text NOT NULL DEFAULT 'blitz',
  time_control integer NOT NULL DEFAULT 300,
  white_time_remaining integer NOT NULL DEFAULT 300,
  black_time_remaining integer NOT NULL DEFAULT 300,
  current_turn text NOT NULL DEFAULT 'white',
  status text NOT NULL DEFAULT 'waiting',
  winner text,
  result_reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS game_moves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES online_games(id) ON DELETE CASCADE,
  move_number integer NOT NULL,
  move_notation text NOT NULL,
  from_square text NOT NULL,
  to_square text NOT NULL,
  piece text NOT NULL,
  captured_piece text,
  is_check boolean DEFAULT false,
  is_checkmate boolean DEFAULT false,
  fen_after_move text NOT NULL,
  timestamp timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS saved_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id text NOT NULL,
  game_name text NOT NULL,
  game_mode text NOT NULL,
  current_fen text NOT NULL,
  move_history jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_online_games_status ON online_games(status);
CREATE INDEX idx_online_games_players ON online_games(white_player_id, black_player_id);
CREATE INDEX idx_game_moves_game_id ON game_moves(game_id);
CREATE INDEX idx_saved_games_player_id ON saved_games(player_id);

-- Enable real-time replication for online_games table
ALTER TABLE online_games REPLICA IDENTITY FULL;
ALTER TABLE game_moves REPLICA IDENTITY FULL;