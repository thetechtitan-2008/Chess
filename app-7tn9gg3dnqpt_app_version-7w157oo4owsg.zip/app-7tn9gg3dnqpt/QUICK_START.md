# 🚀 Quick Start Guide - Naruto Chess Game

## Deploy to Netlify in 3 Steps

### 1️⃣ Push to Git
```bash
git push origin main
```

### 2️⃣ Connect to Netlify
- Go to https://app.netlify.com
- Click "Add new site" → "Import an existing project"
- Select your repository

### 3️⃣ Configure & Deploy
**Build Settings** (auto-detected from netlify.toml):
- Build command: `pnpm install && pnpm run build`
- Publish directory: `dist`
- Node version: `20`

**Environment Variables** (add in Netlify dashboard):
```
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

Click "Deploy site" → Done! 🎉

---

## Local Development

### Install Dependencies
```bash
pnpm install
```

### Run Development Server
```bash
pnpm run dev
```

### Build for Production
```bash
pnpm run build
```

### Preview Production Build
```bash
pnpm run preview
```

### Run Linter
```bash
pnpm run lint
```

---

## Environment Variables

Create `.env` file in root directory:
```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

Get these from your Supabase project:
1. Go to https://app.supabase.com
2. Select your project
3. Settings → API
4. Copy Project URL and anon/public key

---

## Game Features

### 🌐 Multiplayer Online
- Create private games with shareable codes
- Find random opponents with matchmaking
- Real-time move synchronization
- Auto-scroll to game board

### 🤖 AI Training
- 4 difficulty levels (Easy, Medium, Hard, Expert)
- Adjustable time controls
- Perfect for practice

### 👥 Local 2-Player
- Play on same device
- Hot-seat gameplay
- All chess features available

---

## Key Files

- `netlify.toml` - Netlify configuration
- `NETLIFY_DEPLOY.md` - Detailed deployment guide
- `FINAL_SUMMARY.md` - Complete feature documentation
- `TODO.md` - Project status and achievements

---

## Support

- **Netlify Docs**: https://docs.netlify.com
- **Supabase Docs**: https://supabase.com/docs
- **Vite Docs**: https://vitejs.dev

---

## ✅ Checklist Before Deploy

- [x] All code committed to Git
- [x] netlify.toml configured
- [x] Environment variables ready
- [x] Zero linting errors
- [x] Zero TypeScript errors
- [x] Build tested locally
- [x] Supabase project created

---

**That's it! Your Naruto Chess Game is ready to deploy!** 🎮🍥

**Believe it! Dattebayo!** ⚡
